[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Provider](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Provider(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`