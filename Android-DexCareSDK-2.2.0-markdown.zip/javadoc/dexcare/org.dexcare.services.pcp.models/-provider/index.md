[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Provider](./index.md)

# Provider

`data class Provider`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Provider(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [name](name.md) | `val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
