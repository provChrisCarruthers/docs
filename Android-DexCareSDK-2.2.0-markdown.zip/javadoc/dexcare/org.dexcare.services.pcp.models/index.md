[dexcare](../index.md) / [org.dexcare.services.pcp.models](./index.md)

## Package org.dexcare.services.pcp.models

### Types

| Name | Summary |
|---|---|
| [Department](-department/index.md) | `data class Department` |
| [PcpAppointment](-pcp-appointment/index.md) | `data class PcpAppointment` |
| [Provider](-provider/index.md) | `data class Provider` |
| [Vendor](-vendor/index.md) | `enum class Vendor` |
| [VirtualMeeting](-virtual-meeting/index.md) | `data class VirtualMeeting` |
| [VisitType](-visit-type/index.md) | `class VisitType` |
