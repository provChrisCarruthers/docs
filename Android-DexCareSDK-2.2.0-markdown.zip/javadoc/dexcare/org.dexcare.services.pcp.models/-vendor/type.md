[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Vendor](index.md) / [type](./type.md)

# type

`val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)