[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Vendor](index.md) / [Teams](./-teams.md)

# Teams

`Teams`