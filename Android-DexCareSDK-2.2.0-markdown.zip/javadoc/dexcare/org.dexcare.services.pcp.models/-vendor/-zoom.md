[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Vendor](index.md) / [Zoom](./-zoom.md)

# Zoom

`Zoom`