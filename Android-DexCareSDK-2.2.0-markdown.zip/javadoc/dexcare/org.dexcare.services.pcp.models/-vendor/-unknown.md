[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Vendor](index.md) / [Unknown](./-unknown.md)

# Unknown

`Unknown`