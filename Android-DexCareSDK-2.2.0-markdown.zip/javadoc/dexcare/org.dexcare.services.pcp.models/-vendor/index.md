[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Vendor](./index.md)

# Vendor

`enum class Vendor`

### Enum Values

| Name | Summary |
|---|---|
| [Unknown](-unknown.md) |  |
| [Teams](-teams.md) |  |
| [Zoom](-zoom.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
