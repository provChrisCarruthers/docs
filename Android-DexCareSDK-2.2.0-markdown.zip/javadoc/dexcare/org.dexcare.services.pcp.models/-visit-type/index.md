[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VisitType](./index.md)

# VisitType

`class VisitType`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `VisitType(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [name](name.md) | `val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
