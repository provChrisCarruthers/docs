[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VisitType](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`VisitType(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`