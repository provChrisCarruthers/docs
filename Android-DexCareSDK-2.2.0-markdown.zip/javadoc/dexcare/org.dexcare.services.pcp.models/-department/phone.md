[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Department](index.md) / [phone](./phone.md)

# phone

`val phone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`