[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Department](./index.md)

# Department

`data class Department`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Department(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, phone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?)` |

### Properties

| Name | Summary |
|---|---|
| [name](name.md) | `val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [phone](phone.md) | `val phone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
