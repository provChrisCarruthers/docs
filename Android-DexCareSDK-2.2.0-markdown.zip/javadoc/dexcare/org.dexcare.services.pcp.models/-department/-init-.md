[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Department](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Department(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, phone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?)`