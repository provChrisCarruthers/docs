[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [Department](index.md) / [name](./name.md)

# name

`val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)