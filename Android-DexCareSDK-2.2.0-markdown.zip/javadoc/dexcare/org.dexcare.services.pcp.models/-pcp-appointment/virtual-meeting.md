[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [virtualMeeting](./virtual-meeting.md)

# virtualMeeting

`val virtualMeeting: `[`VirtualMeeting`](../-virtual-meeting/index.md)`?`