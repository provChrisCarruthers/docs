[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`PcpAppointment(identifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, visitType: `[`VisitType`](../-visit-type/index.md)`, provider: `[`Provider`](../-provider/index.md)`? = null, department: `[`Department`](../-department/index.md)`? = null, virtualMeeting: `[`VirtualMeeting`](../-virtual-meeting/index.md)`? = null)`