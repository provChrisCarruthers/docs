[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](./index.md)

# PcpAppointment

`data class PcpAppointment`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `PcpAppointment(identifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, visitType: `[`VisitType`](../-visit-type/index.md)`, provider: `[`Provider`](../-provider/index.md)`? = null, department: `[`Department`](../-department/index.md)`? = null, virtualMeeting: `[`VirtualMeeting`](../-virtual-meeting/index.md)`? = null)` |

### Properties

| Name | Summary |
|---|---|
| [department](department.md) | `val department: `[`Department`](../-department/index.md)`?` |
| [endTime](end-time.md) | `val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [identifier](identifier.md) | `val identifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [provider](provider.md) | `val provider: `[`Provider`](../-provider/index.md)`?` |
| [startTime](start-time.md) | `val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [status](status.md) | `val status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [virtualMeeting](virtual-meeting.md) | `val virtualMeeting: `[`VirtualMeeting`](../-virtual-meeting/index.md)`?` |
| [visitType](visit-type.md) | `val visitType: `[`VisitType`](../-visit-type/index.md) |
