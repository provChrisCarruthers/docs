[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [department](./department.md)

# department

`val department: `[`Department`](../-department/index.md)`?`