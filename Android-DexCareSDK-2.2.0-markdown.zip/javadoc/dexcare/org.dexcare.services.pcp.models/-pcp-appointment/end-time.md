[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [endTime](./end-time.md)

# endTime

`val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)