[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [startTime](./start-time.md)

# startTime

`val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)