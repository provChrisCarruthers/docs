[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [provider](./provider.md)

# provider

`val provider: `[`Provider`](../-provider/index.md)`?`