[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [PcpAppointment](index.md) / [visitType](./visit-type.md)

# visitType

`val visitType: `[`VisitType`](../-visit-type/index.md)