[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VirtualMeeting](index.md) / [vendor](./vendor.md)

# vendor

`val vendor: `[`Vendor`](../-vendor/index.md)