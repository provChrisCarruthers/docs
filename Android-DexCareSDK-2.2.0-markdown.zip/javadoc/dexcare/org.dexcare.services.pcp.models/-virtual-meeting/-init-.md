[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VirtualMeeting](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`VirtualMeeting(link: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?, vendor: `[`Vendor`](../-vendor/index.md)`)`