[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VirtualMeeting](./index.md)

# VirtualMeeting

`data class VirtualMeeting`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `VirtualMeeting(link: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?, vendor: `[`Vendor`](../-vendor/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [link](link.md) | `val link: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [vendor](vendor.md) | `val vendor: `[`Vendor`](../-vendor/index.md) |
