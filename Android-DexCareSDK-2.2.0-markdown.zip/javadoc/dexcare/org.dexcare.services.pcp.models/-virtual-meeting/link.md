[dexcare](../../index.md) / [org.dexcare.services.pcp.models](../index.md) / [VirtualMeeting](index.md) / [link](./link.md)

# link

`val link: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`