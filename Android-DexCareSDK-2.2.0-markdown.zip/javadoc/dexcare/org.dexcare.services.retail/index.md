[dexcare](../index.md) / [org.dexcare.services.retail](./index.md)

## Package org.dexcare.services.retail

### Types

| Name | Summary |
|---|---|
| [RetailService](-retail-service/index.md) | `interface RetailService` |
