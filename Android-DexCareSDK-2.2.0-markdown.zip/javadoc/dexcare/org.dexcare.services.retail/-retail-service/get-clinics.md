[dexcare](../../index.md) / [org.dexcare.services.retail](../index.md) / [RetailService](index.md) / [getClinics](./get-clinics.md)

# getClinics

`abstract fun getClinics(brand: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`>>`

Provides an api to get a list of clinics

### Parameters

`brand` -

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

