[dexcare](../../index.md) / [org.dexcare.services.retail](../index.md) / [RetailService](index.md) / [scheduleRetailAppointment](./schedule-retail-appointment.md)

# scheduleRetailAppointment

`abstract fun scheduleRetailAppointment(paymentMethod: `[`PaymentMethod`](../../org.dexcare.services.models/-payment-method/index.md)`, retailVisitInformation: `[`RetailVisitInformation`](../../org.dexcare.services.retail.models/-retail-visit-information/index.md)`, timeSlot: `[`TimeSlot`](../../org.dexcare.services.retail.models/-time-slot/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>`

Provides an api to schedule a retail visit

### Parameters

`paymentMethod` -

`retailVisitInformation` -

`timeSlot` -

### Exceptions

`org.dexcare.services.retail.errors.SomeoneElseHasBookedError` -

`org.dexcare.services.retail.errors.AlreadyBookedAtSameTimeError` -

`org.dexcare.services.retail.errors.FailedToBookError` -

`org.dexcare.services.retail.errors.UnavailableAppointmentError` -

`org.dexcare.services.retail.errors.TimeSlotInPastError` -

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

[org.dexcare.services.models.CreditCardInfo](../../org.dexcare.services.models/-credit-card-info/index.md)

[org.dexcare.services.models.SelfManualInsurance](../../org.dexcare.services.models/-self-manual-insurance/index.md)

[org.dexcare.services.models.SomeoneElseManualInsurance](../../org.dexcare.services.models/-someone-else-manual-insurance/index.md)

[org.dexcare.services.models.SelfImageInsurance](../../org.dexcare.services.models/-self-image-insurance/index.md)

[org.dexcare.services.models.SomeoneElseImageInsurance](../../org.dexcare.services.models/-someone-else-image-insurance/index.md)

[org.dexcare.services.models.OnFileInsurance](../../org.dexcare.services.models/-on-file-insurance/index.md)

[org.dexcare.services.models.CouponCodeInfo](../../org.dexcare.services.models/-coupon-code-info/index.md)

[org.dexcare.services.models.SelfPayment](../../org.dexcare.services.models/-self-payment/index.md)

