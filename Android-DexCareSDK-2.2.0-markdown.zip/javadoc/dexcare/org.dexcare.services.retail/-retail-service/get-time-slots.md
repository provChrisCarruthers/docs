[dexcare](../../index.md) / [org.dexcare.services.retail](../index.md) / [RetailService](index.md) / [getTimeSlots](./get-time-slots.md)

# getTimeSlots

`abstract fun getTimeSlots(departmentName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, allowedVisitType: `[`AllowedVisitType`](../../org.dexcare.services.retail.models/-allowed-visit-type/index.md)`? = null): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`ClinicTimeSlot`](../../org.dexcare.services.retail.models/-clinic-time-slot/index.md)`>`

Provides an api to get time slots for a clinic

### Parameters

`departmentName` - This can be retrieved from a Clinic object

`allowedVisitType` - The AllowedVisitType object returned in the Clinic object.
It contains a property "visitType" which will be used as a filter in the getTimeslots API call.
The visitType should almost always be "Illness".
When allowedVisitType is null, "Illness" will be used.

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

[Clinic](../../org.dexcare.services.retail.models/-clinic/index.md)

