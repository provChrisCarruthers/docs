[dexcare](../../index.md) / [org.dexcare.services.retail](../index.md) / [RetailService](index.md) / [uploadInsuranceCard](./upload-insurance-card.md)

# uploadInsuranceCard

`abstract fun uploadInsuranceCard(front: `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`, back: `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`>`

Provides an api to allow uploading of front and back of insurance card

### Parameters

`front` - Front of the insurance card

`back` - Back of the insurance card

**Return**
The insurance card url used for booking an appointment

