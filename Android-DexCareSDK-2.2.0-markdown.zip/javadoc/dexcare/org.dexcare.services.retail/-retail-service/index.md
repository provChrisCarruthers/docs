[dexcare](../../index.md) / [org.dexcare.services.retail](../index.md) / [RetailService](./index.md)

# RetailService

`interface RetailService`

### Functions

| Name | Summary |
|---|---|
| [getClinics](get-clinics.md) | Provides an api to get a list of clinics`abstract fun getClinics(brand: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`>>` |
| [getTimeSlots](get-time-slots.md) | Provides an api to get time slots for a clinic`abstract fun getTimeSlots(departmentName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, allowedVisitType: `[`AllowedVisitType`](../../org.dexcare.services.retail.models/-allowed-visit-type/index.md)`? = null): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`ClinicTimeSlot`](../../org.dexcare.services.retail.models/-clinic-time-slot/index.md)`>` |
| [scheduleRetailAppointment](schedule-retail-appointment.md) | Provides an api to schedule a retail visit`abstract fun scheduleRetailAppointment(paymentMethod: `[`PaymentMethod`](../../org.dexcare.services.models/-payment-method/index.md)`, retailVisitInformation: `[`RetailVisitInformation`](../../org.dexcare.services.retail.models/-retail-visit-information/index.md)`, timeSlot: `[`TimeSlot`](../../org.dexcare.services.retail.models/-time-slot/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>` |
| [uploadInsuranceCard](upload-insurance-card.md) | Provides an api to allow uploading of front and back of insurance card`abstract fun uploadInsuranceCard(front: `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`, back: `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`>` |
