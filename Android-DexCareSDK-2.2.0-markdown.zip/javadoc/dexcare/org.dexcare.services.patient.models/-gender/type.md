[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Gender](index.md) / [type](./type.md)

# type

`val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)