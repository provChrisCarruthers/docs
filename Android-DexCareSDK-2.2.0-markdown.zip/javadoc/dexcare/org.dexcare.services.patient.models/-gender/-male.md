[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Gender](index.md) / [Male](./-male.md)

# Male

`Male`