[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Gender](index.md) / [Unknown](./-unknown.md)

# Unknown

`Unknown`