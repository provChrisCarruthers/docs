[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Gender](./index.md)

# Gender

`enum class Gender`

### Enum Values

| Name | Summary |
|---|---|
| [Male](-male.md) |  |
| [Female](-female.md) |  |
| [Other](-other.md) |  |
| [Unknown](-unknown.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
