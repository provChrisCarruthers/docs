[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [DexCarePatient](index.md) / [demographicsLinks](./demographics-links.md)

# demographicsLinks

`val demographicsLinks: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PatientDemographics`](../-patient-demographics/index.md)`>`