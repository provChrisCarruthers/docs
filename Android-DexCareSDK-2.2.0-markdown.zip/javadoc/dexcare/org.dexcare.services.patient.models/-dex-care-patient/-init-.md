[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [DexCarePatient](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`DexCarePatient(patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, identifiers: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`>, demographicsLinks: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PatientDemographics`](../-patient-demographics/index.md)`>)`