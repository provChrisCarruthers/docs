[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [DexCarePatient](./index.md)

# DexCarePatient

`data class DexCarePatient : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `DexCarePatient(patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, identifiers: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`>, demographicsLinks: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PatientDemographics`](../-patient-demographics/index.md)`>)` |

### Properties

| Name | Summary |
|---|---|
| [demographicsLinks](demographics-links.md) | `val demographicsLinks: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PatientDemographics`](../-patient-demographics/index.md)`>` |
| [identifiers](identifiers.md) | `val identifiers: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`>` |
| [patientGuid](patient-guid.md) | `val patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |

### Functions

| Name | Summary |
|---|---|
| [getDemographicsForEhr](get-demographics-for-ehr.md) | `fun getDemographicsForEhr(ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`PatientDemographics`](../-patient-demographics/index.md)`?` |
