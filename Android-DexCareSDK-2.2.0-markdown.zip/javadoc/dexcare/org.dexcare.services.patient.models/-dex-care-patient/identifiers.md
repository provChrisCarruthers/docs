[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [DexCarePatient](index.md) / [identifiers](./identifiers.md)

# identifiers

`val identifiers: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`>`