[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [DexCarePatient](index.md) / [getDemographicsForEhr](./get-demographics-for-ehr.md)

# getDemographicsForEhr

`fun getDemographicsForEhr(ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`PatientDemographics`](../-patient-demographics/index.md)`?`