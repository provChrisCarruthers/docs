[dexcare](../index.md) / [org.dexcare.services.patient.models](./index.md)

## Package org.dexcare.services.patient.models

### Types

| Name | Summary |
|---|---|
| [Address](-address/index.md) | `data class Address : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
| [DexCarePatient](-dex-care-patient/index.md) | `data class DexCarePatient : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
| [Gender](-gender/index.md) | `enum class Gender` |
| [HumanName](-human-name/index.md) | `data class HumanName : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
| [PatientDemographics](-patient-demographics/index.md) | `data class PatientDemographics : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
| [PatientGuid](-patient-guid/index.md) | `data class PatientGuid` |
