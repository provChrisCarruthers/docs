[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Address](index.md) / [address](./address.md)

# address

`val address: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)