[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Address](index.md) / [address2](./address2.md)

# address2

`val address2: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`