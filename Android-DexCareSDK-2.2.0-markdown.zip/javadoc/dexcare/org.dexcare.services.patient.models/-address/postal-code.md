[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Address](index.md) / [postalCode](./postal-code.md)

# postalCode

`val postalCode: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)