[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Address](index.md) / [toString](./to-string.md)

# toString

`fun toString(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)