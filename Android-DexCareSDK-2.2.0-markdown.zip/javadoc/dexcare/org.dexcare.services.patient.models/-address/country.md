[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [Address](index.md) / [country](./country.md)

# country

`val country: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`