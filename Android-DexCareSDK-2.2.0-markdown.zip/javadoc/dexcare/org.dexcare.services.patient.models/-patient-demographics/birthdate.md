[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [birthdate](./birthdate.md)

# birthdate

`val birthdate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)