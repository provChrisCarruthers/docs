[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [getEhrSystemName](./get-ehr-system-name.md)

# getEhrSystemName

`fun getEhrSystemName(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`