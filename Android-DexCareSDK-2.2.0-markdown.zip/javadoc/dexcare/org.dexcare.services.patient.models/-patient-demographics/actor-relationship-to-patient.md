[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [actorRelationshipToPatient](./actor-relationship-to-patient.md)

# actorRelationshipToPatient

`val actorRelationshipToPatient: `[`RelationshipToPatient`](../../org.dexcare.services.models/-relationship-to-patient/index.md)`?`

required only for createDependentPatientInEhrSystem call, and only for the userPatientDemographics.Represents the app user -&gt; patient relationship

