[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [addresses](./addresses.md)

# addresses

`val addresses: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Address`](../-address/index.md)`>`