[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [name](./name.md)

# name

`val name: `[`HumanName`](../-human-name/index.md)