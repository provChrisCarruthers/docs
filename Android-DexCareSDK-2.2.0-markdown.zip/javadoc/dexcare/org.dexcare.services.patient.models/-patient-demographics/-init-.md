[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`PatientDemographics(addresses: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Address`](../-address/index.md)`>, birthdate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, email: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../-gender/index.md)`, name: `[`HumanName`](../-human-name/index.md)`, last4SSN: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, homePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, workPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", mobilePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", actorRelationshipToPatient: `[`RelationshipToPatient`](../../org.dexcare.services.models/-relationship-to-patient/index.md)`? = null, identifiers: `[`MutableList`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`> = mutableListOf())`

### Parameters

`actorRelationshipToPatient` - required only for createDependentPatientInEhrSystem call, and only for the userPatientDemographics.Represents the app user -&gt; patient relationship