[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](./index.md)

# PatientDemographics

`data class PatientDemographics : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html)

### Parameters

`actorRelationshipToPatient` - required only for createDependentPatientInEhrSystem call, and only for the userPatientDemographics.Represents the app user -&gt; patient relationship

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `PatientDemographics(addresses: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Address`](../-address/index.md)`>, birthdate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, email: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../-gender/index.md)`, name: `[`HumanName`](../-human-name/index.md)`, last4SSN: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, homePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, workPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", mobilePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", actorRelationshipToPatient: `[`RelationshipToPatient`](../../org.dexcare.services.models/-relationship-to-patient/index.md)`? = null, identifiers: `[`MutableList`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`> = mutableListOf())` |

### Properties

| Name | Summary |
|---|---|
| [actorRelationshipToPatient](actor-relationship-to-patient.md) | required only for createDependentPatientInEhrSystem call, and only for the userPatientDemographics.Represents the app user -&gt; patient relationship`val actorRelationshipToPatient: `[`RelationshipToPatient`](../../org.dexcare.services.models/-relationship-to-patient/index.md)`?` |
| [addresses](addresses.md) | `val addresses: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Address`](../-address/index.md)`>` |
| [birthdate](birthdate.md) | `val birthdate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [email](email.md) | `val email: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [gender](gender.md) | `val gender: `[`Gender`](../-gender/index.md) |
| [homePhone](home-phone.md) | `val homePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [identifiers](identifiers.md) | `val identifiers: `[`MutableList`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-mutable-list/index.html)`<`[`Identifier`](../../org.dexcare.services.appointment.models/-identifier/index.md)`>` |
| [last4SSN](last4-s-s-n.md) | `val last4SSN: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [mobilePhone](mobile-phone.md) | `val mobilePhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [name](name.md) | `val name: `[`HumanName`](../-human-name/index.md) |
| [workPhone](work-phone.md) | `val workPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |

### Functions

| Name | Summary |
|---|---|
| [getEhrSystemName](get-ehr-system-name.md) | `fun getEhrSystemName(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
