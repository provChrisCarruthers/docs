[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientDemographics](index.md) / [gender](./gender.md)

# gender

`val gender: `[`Gender`](../-gender/index.md)