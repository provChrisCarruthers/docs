[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientGuid](index.md) / [patientGuid](./patient-guid.md)

# patientGuid

`val patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)