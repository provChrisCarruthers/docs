[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [PatientGuid](./index.md)

# PatientGuid

`data class PatientGuid`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `PatientGuid(patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [patientGuid](patient-guid.md) | `val patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
