[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [HumanName](index.md) / [suffix](./suffix.md)

# suffix

`val suffix: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)