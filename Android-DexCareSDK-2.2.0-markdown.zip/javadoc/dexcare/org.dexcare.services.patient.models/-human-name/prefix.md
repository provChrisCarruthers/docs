[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [HumanName](index.md) / [prefix](./prefix.md)

# prefix

`val prefix: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)