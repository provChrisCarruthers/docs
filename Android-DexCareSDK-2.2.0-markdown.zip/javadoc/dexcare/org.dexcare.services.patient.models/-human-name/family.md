[dexcare](../../index.md) / [org.dexcare.services.patient.models](../index.md) / [HumanName](index.md) / [family](./family.md)

# family

`val family: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)