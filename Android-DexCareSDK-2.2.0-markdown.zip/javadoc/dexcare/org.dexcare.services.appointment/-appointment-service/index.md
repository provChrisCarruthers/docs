[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](./index.md)

# AppointmentService

`interface AppointmentService`

### Functions

| Name | Summary |
|---|---|
| [cancelRetailVisit](cancel-retail-visit.md) | Provides an api to cancel a retail appointment`abstract fun cancelRetailVisit(appointmentID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, cancelReason: `[`CancelReason`](../../org.dexcare.services.appointment.models/-cancel-reason/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>` |
| [getAppointments](get-appointments.md) | Provides an api to grab patient's appointments`abstract fun ~~getAppointments~~(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Appointment`](../../org.dexcare.services.appointment.models/-appointment/index.md)`>>` |
| [getCancelReasons](get-cancel-reasons.md) | Provides an api to get the list of cancel reasons`abstract fun getCancelReasons(brandName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`CancelReason`](../../org.dexcare.services.appointment.models/-cancel-reason/index.md)`>>` |
| [getPcpAppointments](get-pcp-appointments.md) | Returns a list of PCP appointments`abstract fun getPcpAppointments(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PcpAppointment`](../../org.dexcare.services.pcp.models/-pcp-appointment/index.md)`>>` |
| [getRetailVisits](get-retail-visits.md) | Provides an api to fetch the user's upcoming retail appointments Internally, this will filter visits based on status=requested`abstract fun getRetailVisits(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduledVisit`](../../org.dexcare.services.appointment.models/-scheduled-visit/index.md)`>>` |
