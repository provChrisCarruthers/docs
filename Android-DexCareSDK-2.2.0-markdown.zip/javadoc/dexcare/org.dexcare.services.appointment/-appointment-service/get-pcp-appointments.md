[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](index.md) / [getPcpAppointments](./get-pcp-appointments.md)

# getPcpAppointments

`abstract fun getPcpAppointments(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`PcpAppointment`](../../org.dexcare.services.pcp.models/-pcp-appointment/index.md)`>>`

Returns a list of PCP appointments

### Exceptions

`org.dexcare.services.patient.errors.NoPatientLinkError` -

`org.dexcare.dal.errorHandling.errors.NoBaseUrlSet` -

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

