[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](index.md) / [getCancelReasons](./get-cancel-reasons.md)

# getCancelReasons

`abstract fun getCancelReasons(brandName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`CancelReason`](../../org.dexcare.services.appointment.models/-cancel-reason/index.md)`>>`

Provides an api to get the list of cancel reasons

