[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](index.md) / [getAppointments](./get-appointments.md)

# getAppointments

`abstract fun ~~getAppointments~~(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Appointment`](../../org.dexcare.services.appointment.models/-appointment/index.md)`>>`
**Deprecated:** Use getRetailVisits instead

Provides an api to grab patient's appointments

