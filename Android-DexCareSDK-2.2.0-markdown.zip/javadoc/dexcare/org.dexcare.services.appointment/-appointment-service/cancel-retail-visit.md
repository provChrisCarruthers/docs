[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](index.md) / [cancelRetailVisit](./cancel-retail-visit.md)

# cancelRetailVisit

`abstract fun cancelRetailVisit(appointmentID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, cancelReason: `[`CancelReason`](../../org.dexcare.services.appointment.models/-cancel-reason/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>`

Provides an api to cancel a retail appointment

