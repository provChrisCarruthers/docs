[dexcare](../../index.md) / [org.dexcare.services.appointment](../index.md) / [AppointmentService](index.md) / [getRetailVisits](./get-retail-visits.md)

# getRetailVisits

`abstract fun getRetailVisits(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduledVisit`](../../org.dexcare.services.appointment.models/-scheduled-visit/index.md)`>>`

Provides an api to fetch the user's upcoming retail appointments
Internally, this will filter visits based on status=requested

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

