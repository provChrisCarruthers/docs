[dexcare](../index.md) / [org.dexcare.services.appointment](./index.md)

## Package org.dexcare.services.appointment

### Types

| Name | Summary |
|---|---|
| [AppointmentService](-appointment-service/index.md) | `interface AppointmentService` |
