[dexcare](../index.md) / [org.dexcare.logs](./index.md)

## Package org.dexcare.logs

### Types

| Name | Summary |
|---|---|
| [Logger](-logger/index.md) | `interface Logger` |
