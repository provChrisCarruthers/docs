[dexcare](../index.md) / [org.dexcare.services.patient](./index.md)

## Package org.dexcare.services.patient

### Types

| Name | Summary |
|---|---|
| [PatientService](-patient-service/index.md) | `interface PatientService` |
