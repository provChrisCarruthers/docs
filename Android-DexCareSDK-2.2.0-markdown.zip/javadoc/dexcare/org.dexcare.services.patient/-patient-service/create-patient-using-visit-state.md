[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [createPatientUsingVisitState](./create-patient-using-visit-state.md)

# createPatientUsingVisitState

`abstract fun createPatientUsingVisitState(visitState: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`, brand: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will create a DexCare Patient and link it to the current auth account and Ehr patient record
This api needs to always be called before scheduling a visit.
This api is intended to be used in Virtual.  The ehrSystem will be determined based on the selected visitState and patient address
The Ehr patient record will only be created if it does not already exist in the required ehrSystem.

### Parameters

`visitState` - The initials of the state the user is currently asking for care in, e.g. "CA", "WA"

`patientDemographics` -

`brand` -

### Exceptions

`org.dexcare.services.patient.errors.InvalidPatientDemographicsObjectError` -

**Return**
DexCarePatient

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

