[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [getPatient](./get-patient.md)

# getPatient

`abstract fun getPatient(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will retrieve the DexCare Patient object which has all information about the patient like PatientGuid, demographics links, etc.

**Return**
DexCarePatient

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

