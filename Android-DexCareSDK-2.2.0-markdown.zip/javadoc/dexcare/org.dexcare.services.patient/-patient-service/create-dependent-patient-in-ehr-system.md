[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [createDependentPatientInEhrSystem](./create-dependent-patient-in-ehr-system.md)

# createDependentPatientInEhrSystem

`abstract fun createDependentPatientInEhrSystem(ehrSystem: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, dependentPatientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`, userPatientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will create a DexCare patient record for the dependent, without linking it to the current auth account
This api will create a DexCare patient record for the dependee if necessary, and link it to the current auth account
The dependee's patient record will only be created if it does not already exist in the required ehrSystem.
This api needs to always be called before scheduling a retail visit for a dependent patient.
A new patient record is always created for the dependent.

### Parameters

`ehrSystem` -

`dependentPatientDemographics` -

`userPatientDemographics` - The dependee's demographics

### Exceptions

`org.dexcare.services.patient.errors.InvalidPatientDemographicsObjectError` -

**Return**
DexCarePatient

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

