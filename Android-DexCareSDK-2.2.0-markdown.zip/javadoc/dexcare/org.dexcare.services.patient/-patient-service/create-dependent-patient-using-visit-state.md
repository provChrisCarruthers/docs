[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [createDependentPatientUsingVisitState](./create-dependent-patient-using-visit-state.md)

# createDependentPatientUsingVisitState

`abstract fun createDependentPatientUsingVisitState(visitState: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, dependentPatientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`, userPatientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`, brand: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will create a DexCare patient record for the dependent, without linking it to the current auth account
This api will create a DexCare patient record for the dependee if necessary, and link it to the current auth account
The dependee's patient record will only be created if it does not already exist in the required ehrSystem.
This api needs to always be called before scheduling a child virtual visit.
The ehrSystem will be determined based on the selected visitState and dependent's address
A new patient record is always created for the dependent.

### Parameters

`visitState` - The initials of the state the user is currently asking for care in, e.g. "CA", "WA"

`dependentPatientDemographics` -

`userPatientDemographics` - The dependee's demographics

`brand` -

### Exceptions

`org.dexcare.services.patient.errors.InvalidPatientDemographicsObjectError` -

**Return**
DexCarePatient

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

