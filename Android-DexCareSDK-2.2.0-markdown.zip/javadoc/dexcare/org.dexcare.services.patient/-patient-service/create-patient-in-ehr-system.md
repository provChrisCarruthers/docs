[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [createPatientInEhrSystem](./create-patient-in-ehr-system.md)

# createPatientInEhrSystem

`abstract fun createPatientInEhrSystem(ehrSystem: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientDemographics: `[`PatientDemographics`](../../org.dexcare.services.patient.models/-patient-demographics/index.md)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will create a DexCare Patient and links to the Ehr patient in the specified ehrSystem and it also link it to the current auth account
This api needs to always be called before scheduling a retail visit.
This api is intended to be used when the required ehrSystemName is already determined by the app, e.g. Retail clinic
The Ehr patient record will only be created if it does not already exist in the required ehrSystem.

### Parameters

`ehrSystem` -

`patientDemographics` -

**Return**
DexCarePatient

**See Also**

[NetworkError](../../org.dexcare.services/-network-error/index.md)

