[dexcare](../../index.md) / [org.dexcare.services.patient](../index.md) / [PatientService](index.md) / [createPatientWithMyChart](./create-patient-with-my-chart.md)

# createPatientWithMyChart

`abstract fun createPatientWithMyChart(myChartUserName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, myChartPassword: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ehrSystem: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`DexCarePatient`](../../org.dexcare.services.patient.models/-dex-care-patient/index.md)`>`

This api will create a DexCare patient and links it with the EPIC record associated with the given MyChart account and also link it to the current auth account

### Parameters

`myChartUserName` -

`myChartPassword` -

`ehrSystem` -

**Return**
DexCarePatient

