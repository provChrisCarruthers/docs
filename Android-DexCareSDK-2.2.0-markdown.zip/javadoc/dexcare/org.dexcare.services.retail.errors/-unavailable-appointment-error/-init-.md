[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [UnavailableAppointmentError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`UnavailableAppointmentError()`

This error indicates the time slot selected is unavailable

