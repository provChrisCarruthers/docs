[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [UnavailableAppointmentError](./index.md)

# UnavailableAppointmentError

`class UnavailableAppointmentError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

This error indicates the time slot selected is unavailable

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This error indicates the time slot selected is unavailable`UnavailableAppointmentError()` |
