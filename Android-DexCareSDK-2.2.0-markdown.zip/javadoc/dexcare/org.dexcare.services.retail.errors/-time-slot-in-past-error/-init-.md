[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [TimeSlotInPastError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`TimeSlotInPastError()`

This error indicates the time slot is in the past and no longer available

