[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [TimeSlotInPastError](./index.md)

# TimeSlotInPastError

`class TimeSlotInPastError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

This error indicates the time slot is in the past and no longer available

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This error indicates the time slot is in the past and no longer available`TimeSlotInPastError()` |
