[dexcare](../index.md) / [org.dexcare.services.retail.errors](./index.md)

## Package org.dexcare.services.retail.errors

### Exceptions

| Name | Summary |
|---|---|
| [AlreadyBookedAtSameTimeError](-already-booked-at-same-time-error/index.md) | This error indicates the user has already booked another appointment at the same time`class AlreadyBookedAtSameTimeError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [FailedToBookError](-failed-to-book-error/index.md) | This is a general error for when the user is unable to book an appointment`class FailedToBookError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [SomeoneElseHasBookedError](-someone-else-has-booked-error/index.md) | This error indicates the time slot has already been booked by another user`class SomeoneElseHasBookedError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [TimeSlotInPastError](-time-slot-in-past-error/index.md) | This error indicates the time slot is in the past and no longer available`class TimeSlotInPastError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [UnavailableAppointmentError](-unavailable-appointment-error/index.md) | This error indicates the time slot selected is unavailable`class UnavailableAppointmentError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
