[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [AlreadyBookedAtSameTimeError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`AlreadyBookedAtSameTimeError()`

This error indicates the user has already booked another appointment at the same time

