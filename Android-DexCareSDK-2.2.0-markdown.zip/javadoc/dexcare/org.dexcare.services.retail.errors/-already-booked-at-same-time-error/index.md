[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [AlreadyBookedAtSameTimeError](./index.md)

# AlreadyBookedAtSameTimeError

`class AlreadyBookedAtSameTimeError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

This error indicates the user has already booked another appointment at the same time

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This error indicates the user has already booked another appointment at the same time`AlreadyBookedAtSameTimeError()` |
