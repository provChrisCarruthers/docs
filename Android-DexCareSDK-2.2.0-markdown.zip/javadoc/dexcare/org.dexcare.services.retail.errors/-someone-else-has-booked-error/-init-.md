[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [SomeoneElseHasBookedError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SomeoneElseHasBookedError()`

This error indicates the time slot has already been booked by another user

