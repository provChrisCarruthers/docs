[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [SomeoneElseHasBookedError](./index.md)

# SomeoneElseHasBookedError

`class SomeoneElseHasBookedError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

This error indicates the time slot has already been booked by another user

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This error indicates the time slot has already been booked by another user`SomeoneElseHasBookedError()` |
