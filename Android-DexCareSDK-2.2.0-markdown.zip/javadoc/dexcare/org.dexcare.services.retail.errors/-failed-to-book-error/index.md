[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [FailedToBookError](./index.md)

# FailedToBookError

`class FailedToBookError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

This is a general error for when the user is unable to book an appointment

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This is a general error for when the user is unable to book an appointment`FailedToBookError()` |
