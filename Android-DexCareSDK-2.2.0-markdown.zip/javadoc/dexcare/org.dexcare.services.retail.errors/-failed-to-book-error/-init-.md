[dexcare](../../index.md) / [org.dexcare.services.retail.errors](../index.md) / [FailedToBookError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`FailedToBookError()`

This is a general error for when the user is unable to book an appointment

