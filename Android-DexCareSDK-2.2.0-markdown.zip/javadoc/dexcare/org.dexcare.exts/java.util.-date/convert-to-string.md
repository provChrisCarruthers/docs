[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [java.util.Date](index.md) / [convertToString](./convert-to-string.md)

# convertToString

`fun `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`.convertToString(format: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, timeZone: `[`TimeZone`](https://docs.oracle.com/javase/6/docs/api/java/util/TimeZone.html)` = TimeZone.getDefault()): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)