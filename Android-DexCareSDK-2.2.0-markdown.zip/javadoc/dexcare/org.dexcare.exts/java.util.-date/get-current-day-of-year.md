[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [java.util.Date](index.md) / [getCurrentDayOfYear](./get-current-day-of-year.md)

# getCurrentDayOfYear

`fun `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`.getCurrentDayOfYear(timeZone: `[`TimeZone`](https://docs.oracle.com/javase/6/docs/api/java/util/TimeZone.html)` = TimeZone.getDefault()): `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)