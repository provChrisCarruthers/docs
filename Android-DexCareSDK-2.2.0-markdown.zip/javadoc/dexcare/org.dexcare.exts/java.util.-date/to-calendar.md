[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [java.util.Date](index.md) / [toCalendar](./to-calendar.md)

# toCalendar

`fun `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`.toCalendar(timeZone: `[`TimeZone`](https://docs.oracle.com/javase/6/docs/api/java/util/TimeZone.html)` = TimeZone.getDefault()): `[`Calendar`](https://docs.oracle.com/javase/6/docs/api/java/util/Calendar.html)