[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [java.util.Date](index.md) / [getCurrentMinutes](./get-current-minutes.md)

# getCurrentMinutes

`fun `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`.getCurrentMinutes(timeZone: `[`TimeZone`](https://docs.oracle.com/javase/6/docs/api/java/util/TimeZone.html)` = TimeZone.getDefault()): `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)