[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [java.util.Date](index.md) / [getCurrentDay](./get-current-day.md)

# getCurrentDay

`fun `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`.getCurrentDay(timeZone: `[`TimeZone`](https://docs.oracle.com/javase/6/docs/api/java/util/TimeZone.html)` = TimeZone.getDefault()): `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)