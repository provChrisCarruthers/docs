[dexcare](../index.md) / [org.dexcare.exts](./index.md)

## Package org.dexcare.exts

### Extensions for External Classes

| Name | Summary |
|---|---|
| [android.graphics.Bitmap](android.graphics.-bitmap/index.md) |  |
| [io.reactivex.Completable](io.reactivex.-completable/index.md) |  |
| [io.reactivex.Single](io.reactivex.-single/index.md) |  |
| [java.util.Date](java.util.-date/index.md) |  |
| [retrofit2.HttpException](retrofit2.-http-exception/index.md) |  |

### Functions

| Name | Summary |
|---|---|
| [convertToRxJava](convert-to-rx-java.md) | `fun <T> `[`DataObserver`](../org.dexcare.dal/-data-observer/index.md)`<T>.convertToRxJava(): Single<T>` |
| [getNow](get-now.md) | `fun <T> `[`DataObserver`](../org.dexcare.dal/-data-observer/index.md)`<T>.getNow(): `[`Pair`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-pair/index.html)`<T?, `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`?>` |
| [getObject](get-object.md) | `fun <T> getObject(qualifier: Qualifier? = null, parameters: ParametersDefinition? = null): T` |
