[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [android.graphics.Bitmap](./index.md)

### Extensions for android.graphics.Bitmap

| Name | Summary |
|---|---|
| [createMultipartBodyPart](create-multipart-body-part.md) | `fun `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`.createMultipartBodyPart(imageName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): Part` |
