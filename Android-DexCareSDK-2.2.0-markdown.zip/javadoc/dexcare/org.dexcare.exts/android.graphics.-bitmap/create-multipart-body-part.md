[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [android.graphics.Bitmap](index.md) / [createMultipartBodyPart](./create-multipart-body-part.md)

# createMultipartBodyPart

`fun `[`Bitmap`](https://developer.android.com/reference/android/graphics/Bitmap.html)`.createMultipartBodyPart(imageName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): Part`