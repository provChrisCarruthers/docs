[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Single](./index.md)

### Extensions for io.reactivex.Single

| Name | Summary |
|---|---|
| [handleGeneralErrors](handle-general-errors.md) | `fun <T> Single<T>.handleGeneralErrors(baseRetry: `[`BaseRetry`](../../org.dexcare.dal.error-handling.retries/-base-retry/index.md)`? = HttpRetryImpl()): Single<T>` |
| [injectHttpError](inject-http-error.md) | `fun <T> Single<T>.injectHttpError(onErrorReturn: (HttpException) -> `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Single<T>` |
