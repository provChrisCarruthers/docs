[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Single](index.md) / [injectHttpError](./inject-http-error.md)

# injectHttpError

`fun <T> Single<T>.injectHttpError(onErrorReturn: (HttpException) -> `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Single<T>`