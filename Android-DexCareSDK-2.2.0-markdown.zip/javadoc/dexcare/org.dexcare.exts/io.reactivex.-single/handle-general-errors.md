[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Single](index.md) / [handleGeneralErrors](./handle-general-errors.md)

# handleGeneralErrors

`fun <T> Single<T>.handleGeneralErrors(baseRetry: `[`BaseRetry`](../../org.dexcare.dal.error-handling.retries/-base-retry/index.md)`? = HttpRetryImpl()): Single<T>`