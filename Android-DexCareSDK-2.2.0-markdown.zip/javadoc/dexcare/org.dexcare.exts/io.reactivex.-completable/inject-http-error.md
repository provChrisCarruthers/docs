[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Completable](index.md) / [injectHttpError](./inject-http-error.md)

# injectHttpError

`fun Completable.injectHttpError(onErrorReturn: (HttpException) -> `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Completable`