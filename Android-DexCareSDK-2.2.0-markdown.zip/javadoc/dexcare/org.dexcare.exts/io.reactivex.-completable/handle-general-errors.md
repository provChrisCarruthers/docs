[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Completable](index.md) / [handleGeneralErrors](./handle-general-errors.md)

# handleGeneralErrors

`fun Completable.handleGeneralErrors(baseRetry: `[`BaseRetry`](../../org.dexcare.dal.error-handling.retries/-base-retry/index.md)`? = HttpRetryImpl()): Completable`