[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [io.reactivex.Completable](./index.md)

### Extensions for io.reactivex.Completable

| Name | Summary |
|---|---|
| [handleGeneralErrors](handle-general-errors.md) | `fun Completable.handleGeneralErrors(baseRetry: `[`BaseRetry`](../../org.dexcare.dal.error-handling.retries/-base-retry/index.md)`? = HttpRetryImpl()): Completable` |
| [injectHttpError](inject-http-error.md) | `fun Completable.injectHttpError(onErrorReturn: (HttpException) -> `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Completable` |
