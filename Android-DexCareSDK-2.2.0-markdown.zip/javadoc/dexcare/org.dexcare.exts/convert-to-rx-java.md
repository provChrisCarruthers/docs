[dexcare](../index.md) / [org.dexcare.exts](index.md) / [convertToRxJava](./convert-to-rx-java.md)

# convertToRxJava

`fun <T> `[`DataObserver`](../org.dexcare.dal/-data-observer/index.md)`<T>.convertToRxJava(): Single<T>`