[dexcare](../index.md) / [org.dexcare.exts](index.md) / [getObject](./get-object.md)

# getObject

`inline fun <reified T> getObject(qualifier: Qualifier? = null, noinline parameters: ParametersDefinition? = null): T`