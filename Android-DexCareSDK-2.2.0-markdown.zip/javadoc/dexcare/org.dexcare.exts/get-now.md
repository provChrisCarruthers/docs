[dexcare](../index.md) / [org.dexcare.exts](index.md) / [getNow](./get-now.md)

# getNow

`fun <T> `[`DataObserver`](../org.dexcare.dal/-data-observer/index.md)`<T>.getNow(): `[`Pair`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-pair/index.html)`<T?, `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`?>`