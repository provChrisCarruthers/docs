[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [retrofit2.HttpException](index.md) / [getErrorString](./get-error-string.md)

# getErrorString

`fun HttpException.getErrorString(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`