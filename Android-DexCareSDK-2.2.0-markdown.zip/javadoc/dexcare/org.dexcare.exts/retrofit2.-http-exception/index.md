[dexcare](../../index.md) / [org.dexcare.exts](../index.md) / [retrofit2.HttpException](./index.md)

### Extensions for retrofit2.HttpException

| Name | Summary |
|---|---|
| [getErrorString](get-error-string.md) | `fun HttpException.getErrorString(): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
