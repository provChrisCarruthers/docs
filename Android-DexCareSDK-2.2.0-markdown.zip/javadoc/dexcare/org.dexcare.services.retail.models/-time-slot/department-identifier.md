[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [departmentIdentifier](./department-identifier.md)

# departmentIdentifier

`val departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

A string in the format "{clinic's ehrSystemName}|{departmentId}"

