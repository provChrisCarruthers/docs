[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`TimeSlot(slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, providerNationalId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, providerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, slotType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, visitTypeId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, durationInMins: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, slotDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`)`

Represents an available time for a Retail appointment

### Parameters

`slotId` - A unique identifier for this time slot

`providerNationalId` - This time slot's Provider's national id

`providerId` - A unique identifier representing the Provider for this time slot

`departmentId` - An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system,
but not guaranteed to be unique across multiple ehr systems

`departmentIdentifier` - A string in the format "{clinic's ehrSystemName}|{departmentId}"

`slotType` - What kind of appointment this time slot is for (always Retail)

`visitTypeId` - A unique identifier representing the visit type

`durationInMins` - How long the appointment is, in minutes

`slotDateTime` - The starting time and day of the appointment