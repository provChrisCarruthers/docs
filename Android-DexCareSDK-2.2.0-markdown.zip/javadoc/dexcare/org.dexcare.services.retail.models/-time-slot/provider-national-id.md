[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [providerNationalId](./provider-national-id.md)

# providerNationalId

`val providerNationalId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

This time slot's Provider's national id

