[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [durationInMins](./duration-in-mins.md)

# durationInMins

`val durationInMins: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)

How long the appointment is, in minutes

