[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](./index.md)

# TimeSlot

`data class TimeSlot`

Represents an available time for a Retail appointment

### Parameters

`slotId` - A unique identifier for this time slot

`providerNationalId` - This time slot's Provider's national id

`providerId` - A unique identifier representing the Provider for this time slot

`departmentId` - An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system,
but not guaranteed to be unique across multiple ehr systems

`departmentIdentifier` - A string in the format "{clinic's ehrSystemName}|{departmentId}"

`slotType` - What kind of appointment this time slot is for (always Retail)

`visitTypeId` - A unique identifier representing the visit type

`durationInMins` - How long the appointment is, in minutes

`slotDateTime` - The starting time and day of the appointment

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Represents an available time for a Retail appointment`TimeSlot(slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, providerNationalId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, providerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, slotType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, visitTypeId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, durationInMins: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, slotDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [departmentId](department-id.md) | An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system, but not guaranteed to be unique across multiple ehr systems`val departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [departmentIdentifier](department-identifier.md) | A string in the format "{clinic's ehrSystemName}|{departmentId}"`val departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [durationInMins](duration-in-mins.md) | How long the appointment is, in minutes`val durationInMins: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [providerId](provider-id.md) | A unique identifier representing the Provider for this time slot`val providerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [providerNationalId](provider-national-id.md) | This time slot's Provider's national id`val providerNationalId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [slotDateTime](slot-date-time.md) | The starting time and day of the appointment`val slotDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [slotId](slot-id.md) | A unique identifier for this time slot`val slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [slotType](slot-type.md) | What kind of appointment this time slot is for (always Retail)`val slotType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [visitTypeId](visit-type-id.md) | A unique identifier representing the visit type`val visitTypeId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
