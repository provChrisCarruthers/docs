[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [visitTypeId](./visit-type-id.md)

# visitTypeId

`val visitTypeId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

A unique identifier representing the visit type

