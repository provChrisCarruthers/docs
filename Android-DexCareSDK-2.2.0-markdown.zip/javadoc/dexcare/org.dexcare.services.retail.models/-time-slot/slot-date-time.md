[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [slotDateTime](./slot-date-time.md)

# slotDateTime

`val slotDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

The starting time and day of the appointment

