[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [TimeSlot](index.md) / [slotType](./slot-type.md)

# slotType

`val slotType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

What kind of appointment this time slot is for (always Retail)

