[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [AllowedVisitType](index.md) / [description](./description.md)

# description

`val description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)