[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [AllowedVisitType](index.md) / [visitType](./visit-type.md)

# visitType

`val visitType: `[`VisitType`](../-visit-type/index.md)