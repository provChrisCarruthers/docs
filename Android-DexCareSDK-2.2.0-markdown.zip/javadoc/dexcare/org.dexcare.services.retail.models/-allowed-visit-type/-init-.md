[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [AllowedVisitType](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`AllowedVisitType(visitTypeId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, reasonLabel: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, description: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, visitType: `[`VisitType`](../-visit-type/index.md)`)`