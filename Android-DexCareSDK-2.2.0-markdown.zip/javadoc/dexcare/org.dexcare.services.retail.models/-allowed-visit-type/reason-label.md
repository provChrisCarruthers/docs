[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [AllowedVisitType](index.md) / [reasonLabel](./reason-label.md)

# reasonLabel

`val reasonLabel: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)