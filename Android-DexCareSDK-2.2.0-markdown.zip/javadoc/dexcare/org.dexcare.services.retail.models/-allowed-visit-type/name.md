[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [AllowedVisitType](index.md) / [name](./name.md)

# name

`val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)