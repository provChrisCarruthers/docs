[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [RetailVisitInformation](index.md) / [ehrSystem](./ehr-system.md)

# ehrSystem

`var ehrSystem: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)