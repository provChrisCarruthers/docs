[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [RetailVisitInformation](index.md) / [departmentId](./department-id.md)

# departmentId

`var departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)