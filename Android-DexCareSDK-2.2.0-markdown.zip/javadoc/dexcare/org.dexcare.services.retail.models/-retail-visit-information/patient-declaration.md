[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [RetailVisitInformation](index.md) / [patientDeclaration](./patient-declaration.md)

# patientDeclaration

`val patientDeclaration: `[`PatientDeclaration`](../../org.dexcare.services.models/-patient-declaration/index.md)