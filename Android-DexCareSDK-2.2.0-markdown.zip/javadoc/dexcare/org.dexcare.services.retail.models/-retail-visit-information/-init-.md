[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [RetailVisitInformation](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`RetailVisitInformation(visitReason: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientDeclaration: `[`PatientDeclaration`](../../org.dexcare.services.models/-patient-declaration/index.md)`)`