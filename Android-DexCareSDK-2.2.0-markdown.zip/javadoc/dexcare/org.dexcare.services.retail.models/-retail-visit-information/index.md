[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [RetailVisitInformation](./index.md)

# RetailVisitInformation

`data class RetailVisitInformation`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `RetailVisitInformation(visitReason: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientDeclaration: `[`PatientDeclaration`](../../org.dexcare.services.models/-patient-declaration/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [departmentId](department-id.md) | `var departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ehrSystem](ehr-system.md) | `var ehrSystem: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [patientDeclaration](patient-declaration.md) | `val patientDeclaration: `[`PatientDeclaration`](../../org.dexcare.services.models/-patient-declaration/index.md) |
| [providerId](provider-id.md) | `var providerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [slotId](slot-id.md) | `var slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [visitReason](visit-reason.md) | `val visitReason: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
