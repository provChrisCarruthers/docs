[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ScheduleDay](index.md) / [timeSlots](./time-slots.md)

# timeSlots

`var timeSlots: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`TimeSlot`](../-time-slot/index.md)`>`

A list of TimeSlot objects that are available

