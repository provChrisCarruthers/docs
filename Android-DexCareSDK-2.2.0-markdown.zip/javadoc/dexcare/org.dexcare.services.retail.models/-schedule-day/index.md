[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ScheduleDay](./index.md)

# ScheduleDay

`data class ScheduleDay`

Represents a single day of available time slots for a Retail Appointment

### Parameters

`date` - The date the time slots represent

`timeSlots` - A list of TimeSlot objects that are available

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Represents a single day of available time slots for a Retail Appointment`ScheduleDay(date: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, timeSlots: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`TimeSlot`](../-time-slot/index.md)`> = listOf())` |

### Properties

| Name | Summary |
|---|---|
| [date](date.md) | The date the time slots represent`val date: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [timeSlots](time-slots.md) | A list of TimeSlot objects that are available`var timeSlots: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`TimeSlot`](../-time-slot/index.md)`>` |
