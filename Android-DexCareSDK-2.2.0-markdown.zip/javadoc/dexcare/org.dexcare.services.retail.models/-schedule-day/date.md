[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ScheduleDay](index.md) / [date](./date.md)

# date

`val date: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

The date the time slots represent

