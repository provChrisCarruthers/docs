[dexcare](../index.md) / [org.dexcare.services.retail.models](./index.md)

## Package org.dexcare.services.retail.models

### Types

| Name | Summary |
|---|---|
| [AllowedVisitType](-allowed-visit-type/index.md) | `data class AllowedVisitType` |
| [Clinic](-clinic/index.md) | `data class Clinic` |
| [ClinicTimeSlot](-clinic-time-slot/index.md) | Represents a grouping of time slots for a particular Retail clinic`data class ClinicTimeSlot` |
| [OpenDay](-open-day/index.md) | `data class OpenDay` |
| [OpenHours](-open-hours/index.md) | `data class OpenHours` |
| [RetailVisitInformation](-retail-visit-information/index.md) | `data class RetailVisitInformation` |
| [ScheduleDay](-schedule-day/index.md) | Represents a single day of available time slots for a Retail Appointment`data class ScheduleDay` |
| [TimeSlot](-time-slot/index.md) | Represents an available time for a Retail appointment`data class TimeSlot` |
| [VisitType](-visit-type/index.md) | An enum representing visit types supported by Epic. In Retail, Illness is the only one in use.`enum class VisitType` |
