[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [AdultPhysical](./-adult-physical.md)

# AdultPhysical

`AdultPhysical`