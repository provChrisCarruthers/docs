[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [Unknown](./-unknown.md)

# Unknown

`Unknown`