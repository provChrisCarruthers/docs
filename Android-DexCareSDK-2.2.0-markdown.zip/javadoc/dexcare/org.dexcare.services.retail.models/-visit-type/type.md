[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [type](./type.md)

# type

`val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)