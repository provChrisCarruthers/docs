[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [Virtual](./-virtual.md)

# Virtual

`Virtual`