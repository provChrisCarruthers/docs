[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [Wellness](./-wellness.md)

# Wellness

`Wellness`