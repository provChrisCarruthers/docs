[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [WellChild](./-well-child.md)

# WellChild

`WellChild`