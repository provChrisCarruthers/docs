[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [ChildPhysical](./-child-physical.md)

# ChildPhysical

`ChildPhysical`