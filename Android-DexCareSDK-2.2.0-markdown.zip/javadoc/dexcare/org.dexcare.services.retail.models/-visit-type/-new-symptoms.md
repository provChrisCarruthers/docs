[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [NewSymptoms](./-new-symptoms.md)

# NewSymptoms

`NewSymptoms`