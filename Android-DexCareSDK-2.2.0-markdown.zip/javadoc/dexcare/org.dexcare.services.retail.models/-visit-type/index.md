[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](./index.md)

# VisitType

`enum class VisitType`

An enum representing visit types supported by Epic.
In Retail, Illness is the only one in use.

### Enum Values

| Name | Summary |
|---|---|
| [Illness](-illness.md) |  |
| [Wellness](-wellness.md) |  |
| [Virtual](-virtual.md) |  |
| [FollowUp](-follow-up.md) |  |
| [NewPatient](-new-patient.md) |  |
| [WellChild](-well-child.md) |  |
| [AdultPhysical](-adult-physical.md) |  |
| [ChildPhysical](-child-physical.md) |  |
| [NewSymptoms](-new-symptoms.md) |  |
| [Unknown](-unknown.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
