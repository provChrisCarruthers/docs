[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [VisitType](index.md) / [Illness](./-illness.md)

# Illness

`Illness`