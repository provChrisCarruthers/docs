[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenHours](./index.md)

# OpenHours

`data class OpenHours`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `OpenHours(startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [endTime](end-time.md) | `val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [startTime](start-time.md) | `val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
