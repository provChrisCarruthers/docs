[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenHours](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`OpenHours(startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`)`