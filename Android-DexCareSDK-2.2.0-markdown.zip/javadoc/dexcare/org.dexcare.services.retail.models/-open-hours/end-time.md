[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenHours](index.md) / [endTime](./end-time.md)

# endTime

`val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)