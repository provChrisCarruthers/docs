[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [getLocation](./get-location.md)

# getLocation

`fun getLocation(): `[`Location`](https://developer.android.com/reference/android/location/Location.html)