[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [isActive](./is-active.md)

# isActive

`val isActive: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)