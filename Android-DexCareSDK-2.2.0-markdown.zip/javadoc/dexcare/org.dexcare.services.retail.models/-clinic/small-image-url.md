[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [smallImageUrl](./small-image-url.md)

# smallImageUrl

`val smallImageUrl: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)