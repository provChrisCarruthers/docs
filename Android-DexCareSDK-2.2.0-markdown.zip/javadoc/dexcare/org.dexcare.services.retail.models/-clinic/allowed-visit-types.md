[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [allowedVisitTypes](./allowed-visit-types.md)

# allowedVisitTypes

`val allowedVisitTypes: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`AllowedVisitType`](../-allowed-visit-type/index.md)`>`