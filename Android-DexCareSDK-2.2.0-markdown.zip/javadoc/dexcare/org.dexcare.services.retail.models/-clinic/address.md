[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [address](./address.md)

# address

`val address: `[`Address`](../../org.dexcare.services.patient.models/-address/index.md)