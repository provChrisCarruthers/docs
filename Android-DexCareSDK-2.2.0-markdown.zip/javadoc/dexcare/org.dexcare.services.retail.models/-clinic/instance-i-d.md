[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [instanceID](./instance-i-d.md)

# instanceID

`val instanceID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)