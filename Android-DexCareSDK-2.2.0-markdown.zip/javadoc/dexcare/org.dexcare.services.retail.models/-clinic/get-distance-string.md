[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [getDistanceString](./get-distance-string.md)

# getDistanceString

`fun getDistanceString(userLocation: `[`Location`](https://developer.android.com/reference/android/location/Location.html)`): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)