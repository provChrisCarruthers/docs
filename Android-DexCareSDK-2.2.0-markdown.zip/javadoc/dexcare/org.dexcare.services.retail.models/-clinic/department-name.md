[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [Clinic](index.md) / [departmentName](./department-name.md)

# departmentName

`val departmentName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)