[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenDay](index.md) / [day](./day.md)

# day

`val day: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)