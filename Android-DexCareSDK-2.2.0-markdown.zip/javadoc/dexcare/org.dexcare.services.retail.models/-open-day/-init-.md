[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenDay](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`OpenDay(day: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, openHours: `[`OpenHours`](../-open-hours/index.md)`)`