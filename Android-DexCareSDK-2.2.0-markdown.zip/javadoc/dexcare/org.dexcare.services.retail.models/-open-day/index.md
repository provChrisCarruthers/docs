[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenDay](./index.md)

# OpenDay

`data class OpenDay`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `OpenDay(day: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, openHours: `[`OpenHours`](../-open-hours/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [day](day.md) | `val day: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [openHours](open-hours.md) | `val openHours: `[`OpenHours`](../-open-hours/index.md) |
