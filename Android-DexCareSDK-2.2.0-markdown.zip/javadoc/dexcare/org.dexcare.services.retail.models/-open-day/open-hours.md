[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [OpenDay](index.md) / [openHours](./open-hours.md)

# openHours

`val openHours: `[`OpenHours`](../-open-hours/index.md)