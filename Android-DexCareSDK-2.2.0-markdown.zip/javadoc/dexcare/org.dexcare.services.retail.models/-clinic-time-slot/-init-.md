[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ClinicTimeSlot(departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, scheduleDays: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduleDay`](../-schedule-day/index.md)`> = listOf(), startDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

Represents a grouping of time slots for a particular Retail clinic

