[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](./index.md)

# ClinicTimeSlot

`data class ClinicTimeSlot`

Represents a grouping of time slots for a particular Retail clinic

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Represents a grouping of time slots for a particular Retail clinic`ClinicTimeSlot(departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, scheduleDays: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduleDay`](../-schedule-day/index.md)`> = listOf(), startDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [departmentId](department-id.md) | An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system, but not guaranteed to be unique across multiple ehr systems.`val departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [endDate](end-date.md) | Time slots starting before this Date/Time are included in the list of ScheduleDays`val endDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [scheduleDays](schedule-days.md) | A list of ScheduleDay objects, each representing all time slots for a particular day`val scheduleDays: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduleDay`](../-schedule-day/index.md)`>` |
| [startDate](start-date.md) | Time slots starting after this Date/Time are included in the list of ScheduleDays`val startDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [timezone](timezone.md) | The timezone of the Retail clinic`val timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
