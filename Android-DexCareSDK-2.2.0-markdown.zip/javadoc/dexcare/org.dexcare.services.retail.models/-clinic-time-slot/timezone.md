[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [timezone](./timezone.md)

# timezone

`val timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The timezone of the Retail clinic

### Property

`timezone` - The timezone of the Retail clinic