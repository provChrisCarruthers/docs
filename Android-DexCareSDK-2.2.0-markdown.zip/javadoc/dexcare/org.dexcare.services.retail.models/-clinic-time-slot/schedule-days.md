[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [scheduleDays](./schedule-days.md)

# scheduleDays

`val scheduleDays: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`ScheduleDay`](../-schedule-day/index.md)`>`

A list of ScheduleDay objects, each representing all time slots for a particular day

### Property

`scheduleDays` - A list of ScheduleDay objects, each representing all time slots for a particular day