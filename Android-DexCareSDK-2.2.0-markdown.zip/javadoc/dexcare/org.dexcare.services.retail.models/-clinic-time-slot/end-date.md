[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [endDate](./end-date.md)

# endDate

`val endDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

Time slots starting before this Date/Time are included in the list of ScheduleDays

### Property

`endDate` - Time slots starting before this Date/Time are included in the list of ScheduleDays