[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [departmentId](./department-id.md)

# departmentId

`val departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system,
but not guaranteed to be unique across multiple ehr systems.

### Property

`departmentId` - An identifier representing the Clinic for this time slot.  Guaranteed to be unique in an ehr system,
but not guaranteed to be unique across multiple ehr systems.