[dexcare](../../index.md) / [org.dexcare.services.retail.models](../index.md) / [ClinicTimeSlot](index.md) / [startDate](./start-date.md)

# startDate

`val startDate: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

Time slots starting after this Date/Time are included in the list of ScheduleDays

### Property

`startDate` - Time slots starting after this Date/Time are included in the list of ScheduleDays