[dexcare](../index.md) / [org.dexcare.dal.exts](./index.md)

## Package org.dexcare.dal.exts

### Extensions for External Classes

| Name | Summary |
|---|---|
| [android.content.Context](android.content.-context/index.md) |  |
| [io.reactivex.Completable](io.reactivex.-completable/index.md) |  |
| [io.reactivex.Flowable](io.reactivex.-flowable/index.md) |  |
| [io.reactivex.Observable](io.reactivex.-observable/index.md) |  |
| [io.reactivex.Single](io.reactivex.-single/index.md) |  |
