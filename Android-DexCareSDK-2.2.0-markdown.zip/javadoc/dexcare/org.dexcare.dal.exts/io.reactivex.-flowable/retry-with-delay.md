[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Flowable](index.md) / [retryWithDelay](./retry-with-delay.md)

# retryWithDelay

`fun <T> Flowable<T>.retryWithDelay(retryAttempts: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L): Flowable<T>`