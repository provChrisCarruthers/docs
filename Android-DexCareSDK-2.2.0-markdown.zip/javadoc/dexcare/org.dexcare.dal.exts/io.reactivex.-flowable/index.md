[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Flowable](./index.md)

### Extensions for io.reactivex.Flowable

| Name | Summary |
|---|---|
| [observeOnMain](observe-on-main.md) | `fun <T> Flowable<T>.observeOnMain(): Flowable<T>` |
| [retryWithDelay](retry-with-delay.md) | `fun <T> Flowable<T>.retryWithDelay(retryAttempts: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L): Flowable<T>` |
| [subscribeOnIO](subscribe-on-i-o.md) | `fun <T> Flowable<T>.subscribeOnIO(): Flowable<T>` |
