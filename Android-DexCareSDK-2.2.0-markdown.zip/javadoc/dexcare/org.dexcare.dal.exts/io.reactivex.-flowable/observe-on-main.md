[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Flowable](index.md) / [observeOnMain](./observe-on-main.md)

# observeOnMain

`fun <T> Flowable<T>.observeOnMain(): Flowable<T>`