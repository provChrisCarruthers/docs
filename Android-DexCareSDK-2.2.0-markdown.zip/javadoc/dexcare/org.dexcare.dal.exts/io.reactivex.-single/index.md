[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Single](./index.md)

### Extensions for io.reactivex.Single

| Name | Summary |
|---|---|
| [observeOnMain](observe-on-main.md) | `fun <T> Single<T>.observeOnMain(): Single<T>` |
| [retryWithDelay](retry-with-delay.md) | `fun <T> Single<T>.retryWithDelay(retryAttempts: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L): Single<T>` |
| [subscribeForDataObs](subscribe-for-data-obs.md) | Provides an extension function for generating a dataObserver for your data class`fun <T> Single<T>.subscribeForDataObs(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<T>` |
| [subscribeOnIO](subscribe-on-i-o.md) | `fun <T> Single<T>.subscribeOnIO(): Single<T>` |
