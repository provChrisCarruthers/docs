[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Single](index.md) / [observeOnMain](./observe-on-main.md)

# observeOnMain

`fun <T> Single<T>.observeOnMain(): Single<T>`