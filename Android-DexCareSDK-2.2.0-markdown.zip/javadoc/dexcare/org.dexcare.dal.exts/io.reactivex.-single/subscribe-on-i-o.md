[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Single](index.md) / [subscribeOnIO](./subscribe-on-i-o.md)

# subscribeOnIO

`fun <T> Single<T>.subscribeOnIO(): Single<T>`