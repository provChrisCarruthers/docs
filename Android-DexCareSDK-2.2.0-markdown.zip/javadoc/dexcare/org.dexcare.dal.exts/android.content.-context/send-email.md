[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [android.content.Context](index.md) / [sendEmail](./send-email.md)

# sendEmail

`fun `[`Context`](https://developer.android.com/reference/android/content/Context.html)`.sendEmail(subject: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, addresses: `[`Array`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)`<`[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`>): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)