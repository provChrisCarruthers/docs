[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [android.content.Context](index.md) / [readFromRaw](./read-from-raw.md)

# readFromRaw

`fun `[`Context`](https://developer.android.com/reference/android/content/Context.html)`.readFromRaw(@RawRes rawID: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`): `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

An extension function for reading files in the Raw resource folder and converting them to a string

