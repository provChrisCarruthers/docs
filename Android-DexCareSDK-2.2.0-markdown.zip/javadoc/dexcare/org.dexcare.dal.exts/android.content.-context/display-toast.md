[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [android.content.Context](index.md) / [displayToast](./display-toast.md)

# displayToast

`fun `[`Context`](https://developer.android.com/reference/android/content/Context.html)`.displayToast(text: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)