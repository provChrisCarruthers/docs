[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Completable](index.md) / [subscribeOnIO](./subscribe-on-i-o.md)

# subscribeOnIO

`fun Completable.subscribeOnIO(): Completable`