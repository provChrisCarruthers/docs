[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Completable](index.md) / [observeOnMain](./observe-on-main.md)

# observeOnMain

`fun Completable.observeOnMain(): Completable`