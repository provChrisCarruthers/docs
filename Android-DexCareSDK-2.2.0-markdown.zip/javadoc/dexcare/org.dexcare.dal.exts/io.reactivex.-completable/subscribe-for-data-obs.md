[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Completable](index.md) / [subscribeForDataObs](./subscribe-for-data-obs.md)

# subscribeForDataObs

`fun Completable.subscribeForDataObs(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>`

Provides an extension function for generating a dataObserver for your data class

