[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Completable](./index.md)

### Extensions for io.reactivex.Completable

| Name | Summary |
|---|---|
| [observeOnMain](observe-on-main.md) | `fun Completable.observeOnMain(): Completable` |
| [retryWithDelay](retry-with-delay.md) | `fun Completable.retryWithDelay(retryAttempts: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L): Completable` |
| [subscribeForDataObs](subscribe-for-data-obs.md) | Provides an extension function for generating a dataObserver for your data class`fun Completable.subscribeForDataObs(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<`[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`>` |
| [subscribeOnIO](subscribe-on-i-o.md) | `fun Completable.subscribeOnIO(): Completable` |
