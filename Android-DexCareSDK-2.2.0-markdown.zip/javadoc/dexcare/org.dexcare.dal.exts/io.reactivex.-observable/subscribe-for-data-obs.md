[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Observable](index.md) / [subscribeForDataObs](./subscribe-for-data-obs.md)

# subscribeForDataObs

`fun <T> Observable<T>.subscribeForDataObs(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<T>`

Provides an extension function for generating a dataObserver for your data class

