[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Observable](./index.md)

### Extensions for io.reactivex.Observable

| Name | Summary |
|---|---|
| [observeOnMain](observe-on-main.md) | `fun <T> Observable<T>.observeOnMain(): Observable<T>` |
| [subscribeForDataObs](subscribe-for-data-obs.md) | Provides an extension function for generating a dataObserver for your data class`fun <T> Observable<T>.subscribeForDataObs(): `[`DataObserver`](../../org.dexcare.dal/-data-observer/index.md)`<T>` |
| [subscribeOnIO](subscribe-on-i-o.md) | `fun <T> Observable<T>.subscribeOnIO(): Observable<T>` |
