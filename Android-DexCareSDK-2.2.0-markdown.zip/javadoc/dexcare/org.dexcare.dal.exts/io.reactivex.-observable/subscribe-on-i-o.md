[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Observable](index.md) / [subscribeOnIO](./subscribe-on-i-o.md)

# subscribeOnIO

`fun <T> Observable<T>.subscribeOnIO(): Observable<T>`