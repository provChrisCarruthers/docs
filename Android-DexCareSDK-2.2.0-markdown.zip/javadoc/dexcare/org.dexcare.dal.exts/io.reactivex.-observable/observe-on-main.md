[dexcare](../../index.md) / [org.dexcare.dal.exts](../index.md) / [io.reactivex.Observable](index.md) / [observeOnMain](./observe-on-main.md)

# observeOnMain

`fun <T> Observable<T>.observeOnMain(): Observable<T>`