[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Mother](./-mother.md)

# Mother

`Mother`