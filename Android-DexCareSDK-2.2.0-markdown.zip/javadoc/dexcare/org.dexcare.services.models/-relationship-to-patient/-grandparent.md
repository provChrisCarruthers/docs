[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Grandparent](./-grandparent.md)

# Grandparent

`Grandparent`