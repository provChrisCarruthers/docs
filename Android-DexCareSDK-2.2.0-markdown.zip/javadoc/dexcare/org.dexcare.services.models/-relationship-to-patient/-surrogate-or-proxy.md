[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [SurrogateOrProxy](./-surrogate-or-proxy.md)

# SurrogateOrProxy

`SurrogateOrProxy`