[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [GrandChild](./-grand-child.md)

# GrandChild

`GrandChild`