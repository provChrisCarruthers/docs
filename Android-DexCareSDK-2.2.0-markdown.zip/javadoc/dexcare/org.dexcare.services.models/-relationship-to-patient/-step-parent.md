[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [StepParent](./-step-parent.md)

# StepParent

`StepParent`