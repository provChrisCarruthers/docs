[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [CaseManager](./-case-manager.md)

# CaseManager

`CaseManager`