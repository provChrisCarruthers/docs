[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [FosterParent](./-foster-parent.md)

# FosterParent

`FosterParent`