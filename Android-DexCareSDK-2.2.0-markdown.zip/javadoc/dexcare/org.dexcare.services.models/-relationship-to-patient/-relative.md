[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Relative](./-relative.md)

# Relative

`Relative`