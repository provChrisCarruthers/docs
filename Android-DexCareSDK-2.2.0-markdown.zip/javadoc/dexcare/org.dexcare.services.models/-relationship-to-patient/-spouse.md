[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Spouse](./-spouse.md)

# Spouse

`Spouse`