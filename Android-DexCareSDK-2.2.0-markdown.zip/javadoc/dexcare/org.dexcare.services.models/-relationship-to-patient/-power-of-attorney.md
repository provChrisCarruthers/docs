[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [PowerOfAttorney](./-power-of-attorney.md)

# PowerOfAttorney

`PowerOfAttorney`