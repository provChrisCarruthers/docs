[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [NonRelative](./-non-relative.md)

# NonRelative

`NonRelative`