[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Daughter](./-daughter.md)

# Daughter

`Daughter`