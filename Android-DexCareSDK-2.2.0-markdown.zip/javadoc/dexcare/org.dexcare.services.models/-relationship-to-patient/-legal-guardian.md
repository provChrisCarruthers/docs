[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [LegalGuardian](./-legal-guardian.md)

# LegalGuardian

`LegalGuardian`