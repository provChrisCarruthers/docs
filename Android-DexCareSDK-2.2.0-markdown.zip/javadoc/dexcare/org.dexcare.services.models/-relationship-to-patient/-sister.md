[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Sister](./-sister.md)

# Sister

`Sister`