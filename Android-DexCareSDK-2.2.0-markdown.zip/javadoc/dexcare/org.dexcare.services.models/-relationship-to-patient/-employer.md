[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [Employer](./-employer.md)

# Employer

`Employer`