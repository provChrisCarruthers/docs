[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](index.md) / [DomesticPartner](./-domestic-partner.md)

# DomesticPartner

`DomesticPartner`