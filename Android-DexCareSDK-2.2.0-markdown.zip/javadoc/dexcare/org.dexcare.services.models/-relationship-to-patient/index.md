[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [RelationshipToPatient](./index.md)

# RelationshipToPatient

`enum class RelationshipToPatient`

### Enum Values

| Name | Summary |
|---|---|
| [Mother](-mother.md) |  |
| [Father](-father.md) |  |
| [Grandparent](-grandparent.md) |  |
| [StepParent](-step-parent.md) |  |
| [FosterParent](-foster-parent.md) |  |
| [LegalGuardian](-legal-guardian.md) |  |
| [Relative](-relative.md) |  |
| [NonRelative](-non-relative.md) |  |
| [Brother](-brother.md) |  |
| [Sister](-sister.md) |  |
| [Daughter](-daughter.md) |  |
| [Son](-son.md) |  |
| [Friend](-friend.md) |  |
| [GrandChild](-grand-child.md) |  |
| [Spouse](-spouse.md) |  |
| [SignificantOther](-significant-other.md) |  |
| [CaseManager](-case-manager.md) |  |
| [DomesticPartner](-domestic-partner.md) |  |
| [Employer](-employer.md) |  |
| [PatientRefused](-patient-refused.md) |  |
| [PowerOfAttorney](-power-of-attorney.md) |  |
| [SurrogateOrProxy](-surrogate-or-proxy.md) |  |

### Properties

| Name | Summary |
|---|---|
| [id](id.md) | `val id: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
