[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](./index.md)

# Actor

`data class Actor`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Actor(firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, phoneNumber: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`, dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, relationshipToPatient: `[`RelationshipToPatient`](../-relationship-to-patient/index.md)`? = null)` |

### Properties

| Name | Summary |
|---|---|
| [dateOfBirth](date-of-birth.md) | `val dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [firstName](first-name.md) | `val firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [gender](gender.md) | `val gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md) |
| [lastName](last-name.md) | `val lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [phoneNumber](phone-number.md) | `val phoneNumber: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [relationshipToPatient](relationship-to-patient.md) | `val relationshipToPatient: `[`RelationshipToPatient`](../-relationship-to-patient/index.md)`?` |
