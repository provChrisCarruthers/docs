[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](index.md) / [gender](./gender.md)

# gender

`val gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)