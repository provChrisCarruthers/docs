[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](index.md) / [relationshipToPatient](./relationship-to-patient.md)

# relationshipToPatient

`val relationshipToPatient: `[`RelationshipToPatient`](../-relationship-to-patient/index.md)`?`