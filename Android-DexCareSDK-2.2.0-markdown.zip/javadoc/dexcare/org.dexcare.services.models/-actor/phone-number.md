[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](index.md) / [phoneNumber](./phone-number.md)

# phoneNumber

`val phoneNumber: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)