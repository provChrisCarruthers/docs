[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Actor(firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, phoneNumber: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`, dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, relationshipToPatient: `[`RelationshipToPatient`](../-relationship-to-patient/index.md)`? = null)`