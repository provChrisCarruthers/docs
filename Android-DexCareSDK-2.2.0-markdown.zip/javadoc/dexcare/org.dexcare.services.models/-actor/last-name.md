[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [Actor](index.md) / [lastName](./last-name.md)

# lastName

`val lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)