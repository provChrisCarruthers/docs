[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfPayment](./index.md)

# SelfPayment

`class SelfPayment : `[`PaymentMethod`](../-payment-method/index.md)

PaymentMethod for use when the payment will be provided at the time of visit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when the payment will be provided at the time of visit`SelfPayment()` |
