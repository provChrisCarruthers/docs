[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfPayment](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SelfPayment()`

PaymentMethod for use when the payment will be provided at the time of visit

