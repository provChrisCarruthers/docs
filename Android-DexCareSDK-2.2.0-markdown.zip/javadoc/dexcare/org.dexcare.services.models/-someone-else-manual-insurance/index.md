[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SomeoneElseManualInsurance](./index.md)

# SomeoneElseManualInsurance

`class SomeoneElseManualInsurance : `[`InsuranceInfo`](../-insurance-info/index.md)

PaymentMethod for use when the insurance is owned by someone other than the app user.

### Parameters

`firstName` - The insurance owner's first name

`lastName` - The insurance owner's last name

`gender` - The insurance owner's gender

`dateOfBirth` - The insurance owner's date of birth

`insuranceProviderID` -

`insuranceMemberID` -

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when the insurance is owned by someone other than the app user.`SomeoneElseManualInsurance(firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`, dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, insuranceProviderID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, insuranceMemberID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |
