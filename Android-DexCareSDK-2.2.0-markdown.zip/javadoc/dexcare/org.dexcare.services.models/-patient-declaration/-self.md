[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PatientDeclaration](index.md) / [Self](./-self.md)

# Self

`Self`