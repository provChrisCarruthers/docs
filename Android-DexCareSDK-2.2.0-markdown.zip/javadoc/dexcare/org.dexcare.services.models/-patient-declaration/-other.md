[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PatientDeclaration](index.md) / [Other](./-other.md)

# Other

`Other`