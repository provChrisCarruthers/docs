[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PatientDeclaration](./index.md)

# PatientDeclaration

`enum class PatientDeclaration`

### Enum Values

| Name | Summary |
|---|---|
| [Self](-self.md) |  |
| [Other](-other.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
