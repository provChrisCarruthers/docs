[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [CouponCodeInfo](index.md) / [couponCode](./coupon-code.md)

# couponCode

`val couponCode: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The service key that has been applied

