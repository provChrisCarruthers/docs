[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [CouponCodeInfo](./index.md)

# CouponCodeInfo

`class CouponCodeInfo : `[`PaymentMethod`](../-payment-method/index.md)

PaymentMethod for use when a service key has been applied

### Parameters

`couponCode` - The service key that has been applied

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when a service key has been applied`CouponCodeInfo(couponCode: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [couponCode](coupon-code.md) | The service key that has been applied`val couponCode: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
