[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [CouponCodeInfo](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`CouponCodeInfo(couponCode: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

PaymentMethod for use when a service key has been applied

### Parameters

`couponCode` - The service key that has been applied