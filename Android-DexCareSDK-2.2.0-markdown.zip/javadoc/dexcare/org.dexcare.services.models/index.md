[dexcare](../index.md) / [org.dexcare.services.models](./index.md)

## Package org.dexcare.services.models

### Types

| Name | Summary |
|---|---|
| [Actor](-actor/index.md) | `data class Actor` |
| [CouponCodeInfo](-coupon-code-info/index.md) | PaymentMethod for use when a service key has been applied`class CouponCodeInfo : `[`PaymentMethod`](-payment-method/index.md) |
| [CreditCardInfo](-credit-card-info/index.md) | PaymentMethod for use with credit card payments.  Requires stripe library https://stripe.com/docs/mobile/android/basic`class CreditCardInfo : `[`PaymentMethod`](-payment-method/index.md) |
| [InsuranceInfo](-insurance-info/index.md) | `abstract class InsuranceInfo : `[`PaymentMethod`](-payment-method/index.md) |
| [InsurancePayer](-insurance-payer/index.md) | `data class InsurancePayer` |
| [InsurancePayers](-insurance-payers/index.md) | `data class InsurancePayers` |
| [OnFileInsurance](-on-file-insurance/index.md) | PaymentMethod for use when the insurance is already on file`class OnFileInsurance : `[`InsuranceInfo`](-insurance-info/index.md) |
| [PatientDeclaration](-patient-declaration/index.md) | `enum class PatientDeclaration` |
| [PaymentHolderDeclaration](-payment-holder-declaration/index.md) | `enum class PaymentHolderDeclaration` |
| [PaymentMethod](-payment-method/index.md) | `abstract class PaymentMethod` |
| [RelationshipToPatient](-relationship-to-patient/index.md) | `enum class RelationshipToPatient` |
| [SelfImageInsurance](-self-image-insurance/index.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method`class SelfImageInsurance : `[`InsuranceInfo`](-insurance-info/index.md) |
| [SelfManualInsurance](-self-manual-insurance/index.md) | PaymentMethod for use when the insurance is owned by the app user.`class SelfManualInsurance : `[`InsuranceInfo`](-insurance-info/index.md) |
| [SelfPayment](-self-payment/index.md) | PaymentMethod for use when the payment will be provided at the time of visit`class SelfPayment : `[`PaymentMethod`](-payment-method/index.md) |
| [SomeoneElseImageInsurance](-someone-else-image-insurance/index.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method, and the insurance is not owned by the app user.`class SomeoneElseImageInsurance : `[`InsuranceInfo`](-insurance-info/index.md) |
| [SomeoneElseManualInsurance](-someone-else-manual-insurance/index.md) | PaymentMethod for use when the insurance is owned by someone other than the app user.`class SomeoneElseManualInsurance : `[`InsuranceInfo`](-insurance-info/index.md) |
