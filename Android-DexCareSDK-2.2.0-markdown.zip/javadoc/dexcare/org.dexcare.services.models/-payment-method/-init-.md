[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentMethod](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`PaymentMethod(paymentMethod: PaymentMethod)`