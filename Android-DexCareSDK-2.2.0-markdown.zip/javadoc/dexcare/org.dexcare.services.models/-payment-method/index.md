[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentMethod](./index.md)

# PaymentMethod

`abstract class PaymentMethod`

### Types

| Name | Summary |
|---|---|
| [PaymentMethod](-payment-method/index.md) | `enum class PaymentMethod` |

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `PaymentMethod(paymentMethod: PaymentMethod)` |

### Properties

| Name | Summary |
|---|---|
| [paymentMethod](payment-method.md) | `val paymentMethod: PaymentMethod` |

### Inheritors

| Name | Summary |
|---|---|
| [CouponCodeInfo](../-coupon-code-info/index.md) | PaymentMethod for use when a service key has been applied`class CouponCodeInfo : `[`PaymentMethod`](./index.md) |
| [CreditCardInfo](../-credit-card-info/index.md) | PaymentMethod for use with credit card payments.  Requires stripe library https://stripe.com/docs/mobile/android/basic`class CreditCardInfo : `[`PaymentMethod`](./index.md) |
| [InsuranceInfo](../-insurance-info/index.md) | `abstract class InsuranceInfo : `[`PaymentMethod`](./index.md) |
| [SelfPayment](../-self-payment/index.md) | PaymentMethod for use when the payment will be provided at the time of visit`class SelfPayment : `[`PaymentMethod`](./index.md) |
