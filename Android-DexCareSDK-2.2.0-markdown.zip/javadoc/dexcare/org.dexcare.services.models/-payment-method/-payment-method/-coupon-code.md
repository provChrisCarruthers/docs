[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [PaymentMethod](../index.md) / [PaymentMethod](index.md) / [CouponCode](./-coupon-code.md)

# CouponCode

`CouponCode`