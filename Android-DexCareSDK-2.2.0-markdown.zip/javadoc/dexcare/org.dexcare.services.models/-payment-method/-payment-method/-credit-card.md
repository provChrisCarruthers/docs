[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [PaymentMethod](../index.md) / [PaymentMethod](index.md) / [CreditCard](./-credit-card.md)

# CreditCard

`CreditCard`