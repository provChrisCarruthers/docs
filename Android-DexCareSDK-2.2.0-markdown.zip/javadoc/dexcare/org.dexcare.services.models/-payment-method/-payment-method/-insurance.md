[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [PaymentMethod](../index.md) / [PaymentMethod](index.md) / [Insurance](./-insurance.md)

# Insurance

`Insurance`