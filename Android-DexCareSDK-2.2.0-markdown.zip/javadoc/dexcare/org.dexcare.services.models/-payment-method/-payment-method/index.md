[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [PaymentMethod](../index.md) / [PaymentMethod](./index.md)

# PaymentMethod

`enum class PaymentMethod`

### Enum Values

| Name | Summary |
|---|---|
| [CreditCard](-credit-card.md) |  |
| [Insurance](-insurance.md) |  |
| [CouponCode](-coupon-code.md) |  |
| [Self](-self.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
