[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [PaymentMethod](../index.md) / [PaymentMethod](index.md) / [Self](./-self.md)

# Self

`Self`