[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentMethod](index.md) / [paymentMethod](./payment-method.md)

# paymentMethod

`val paymentMethod: PaymentMethod`