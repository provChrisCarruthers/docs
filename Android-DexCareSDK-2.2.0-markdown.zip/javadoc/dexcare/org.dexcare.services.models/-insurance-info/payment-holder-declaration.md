[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](index.md) / [paymentHolderDeclaration](./payment-holder-declaration.md)

# paymentHolderDeclaration

`val paymentHolderDeclaration: `[`PaymentHolderDeclaration`](../-payment-holder-declaration/index.md)`?`