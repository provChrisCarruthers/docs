[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](./index.md)

# InsuranceInfo

`abstract class InsuranceInfo : `[`PaymentMethod`](../-payment-method/index.md)

### Types

| Name | Summary |
|---|---|
| [InsuranceType](-insurance-type/index.md) | `enum class InsuranceType` |

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `InsuranceInfo(insuranceType: InsuranceType, paymentHolderDeclaration: `[`PaymentHolderDeclaration`](../-payment-holder-declaration/index.md)`? = null, firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`? = null, dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`? = null, insuranceProviderID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, insuranceMemberID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null)` |

### Properties

| Name | Summary |
|---|---|
| [dateOfBirth](date-of-birth.md) | `val dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?` |
| [firstName](first-name.md) | `val firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [gender](gender.md) | `var gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`?` |
| [insuranceCardURL](insurance-card-u-r-l.md) | `val insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [insuranceMemberID](insurance-member-i-d.md) | `val insuranceMemberID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [insuranceProviderID](insurance-provider-i-d.md) | `val insuranceProviderID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [insuranceType](insurance-type.md) | `val insuranceType: InsuranceType` |
| [lastName](last-name.md) | `val lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [paymentHolderDeclaration](payment-holder-declaration.md) | `val paymentHolderDeclaration: `[`PaymentHolderDeclaration`](../-payment-holder-declaration/index.md)`?` |

### Inheritors

| Name | Summary |
|---|---|
| [OnFileInsurance](../-on-file-insurance/index.md) | PaymentMethod for use when the insurance is already on file`class OnFileInsurance : `[`InsuranceInfo`](./index.md) |
| [SelfImageInsurance](../-self-image-insurance/index.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method`class SelfImageInsurance : `[`InsuranceInfo`](./index.md) |
| [SelfManualInsurance](../-self-manual-insurance/index.md) | PaymentMethod for use when the insurance is owned by the app user.`class SelfManualInsurance : `[`InsuranceInfo`](./index.md) |
| [SomeoneElseImageInsurance](../-someone-else-image-insurance/index.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method, and the insurance is not owned by the app user.`class SomeoneElseImageInsurance : `[`InsuranceInfo`](./index.md) |
| [SomeoneElseManualInsurance](../-someone-else-manual-insurance/index.md) | PaymentMethod for use when the insurance is owned by someone other than the app user.`class SomeoneElseManualInsurance : `[`InsuranceInfo`](./index.md) |
