[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](index.md) / [insuranceCardURL](./insurance-card-u-r-l.md)

# insuranceCardURL

`val insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`