[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [InsuranceInfo](../index.md) / [InsuranceType](index.md) / [OnFile](./-on-file.md)

# OnFile

`OnFile`