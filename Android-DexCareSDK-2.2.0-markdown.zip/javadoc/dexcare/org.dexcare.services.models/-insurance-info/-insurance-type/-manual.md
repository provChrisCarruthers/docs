[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [InsuranceInfo](../index.md) / [InsuranceType](index.md) / [Manual](./-manual.md)

# Manual

`Manual`