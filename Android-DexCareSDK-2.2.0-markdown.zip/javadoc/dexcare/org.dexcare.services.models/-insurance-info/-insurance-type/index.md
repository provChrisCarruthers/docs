[dexcare](../../../index.md) / [org.dexcare.services.models](../../index.md) / [InsuranceInfo](../index.md) / [InsuranceType](./index.md)

# InsuranceType

`enum class InsuranceType`

### Enum Values

| Name | Summary |
|---|---|
| [Manual](-manual.md) |  |
| [Image](-image.md) |  |
| [OnFile](-on-file.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
