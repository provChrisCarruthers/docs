[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](index.md) / [insuranceType](./insurance-type.md)

# insuranceType

`val insuranceType: InsuranceType`