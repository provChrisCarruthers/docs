[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](index.md) / [gender](./gender.md)

# gender

`var gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`?`