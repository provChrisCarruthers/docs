[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsuranceInfo](index.md) / [dateOfBirth](./date-of-birth.md)

# dateOfBirth

`val dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?`