[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SomeoneElseImageInsurance](./index.md)

# SomeoneElseImageInsurance

`class SomeoneElseImageInsurance : `[`InsuranceInfo`](../-insurance-info/index.md)

PaymentMethod for use when images of the front and back of the insurance card have been uploaded
using the RetailService.uploadInsuranceCard method, and the insurance is not owned by the
app user.

### Parameters

`firstName` - The insurance owner's first name

`lastName` - The insurance owner's last name

`gender` - The insurance owner's gender

`dateOfBirth` - The insurance owner's date of birth

`insuranceCardURL` - the URL as returned by RetailService.uploadInsuranceCard

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method, and the insurance is not owned by the app user.`SomeoneElseImageInsurance(firstName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, lastName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, gender: `[`Gender`](../../org.dexcare.services.patient.models/-gender/index.md)`, dateOfBirth: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |
