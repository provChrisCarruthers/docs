[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayers](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`InsurancePayers(success: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, payersList: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`InsurancePayer`](../-insurance-payer/index.md)`>)`