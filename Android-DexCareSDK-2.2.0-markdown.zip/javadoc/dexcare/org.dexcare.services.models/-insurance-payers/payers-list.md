[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayers](index.md) / [payersList](./payers-list.md)

# payersList

`val payersList: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`InsurancePayer`](../-insurance-payer/index.md)`>`