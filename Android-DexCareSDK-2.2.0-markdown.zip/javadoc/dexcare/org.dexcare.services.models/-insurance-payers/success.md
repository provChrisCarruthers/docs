[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayers](index.md) / [success](./success.md)

# success

`val success: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)