[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayers](./index.md)

# InsurancePayers

`data class InsurancePayers`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `InsurancePayers(success: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, payersList: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`InsurancePayer`](../-insurance-payer/index.md)`>)` |

### Properties

| Name | Summary |
|---|---|
| [payersList](payers-list.md) | `val payersList: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`InsurancePayer`](../-insurance-payer/index.md)`>` |
| [size](size.md) | `val size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [success](success.md) | `val success: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) |
