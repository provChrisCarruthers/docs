[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayers](index.md) / [size](./size.md)

# size

`val size: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)