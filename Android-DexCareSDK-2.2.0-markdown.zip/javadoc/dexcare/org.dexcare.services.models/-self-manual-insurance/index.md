[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfManualInsurance](./index.md)

# SelfManualInsurance

`class SelfManualInsurance : `[`InsuranceInfo`](../-insurance-info/index.md)

PaymentMethod for use when the insurance is owned by the app user.

### Parameters

`insuranceProviderID` -

`insuranceMemberID` -

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when the insurance is owned by the app user.`SelfManualInsurance(insuranceProviderID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, insuranceMemberID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |
