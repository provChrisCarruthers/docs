[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfManualInsurance](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SelfManualInsurance(insuranceProviderID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, insuranceMemberID: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

PaymentMethod for use when the insurance is owned by the app user.

### Parameters

`insuranceProviderID` -

`insuranceMemberID` - 