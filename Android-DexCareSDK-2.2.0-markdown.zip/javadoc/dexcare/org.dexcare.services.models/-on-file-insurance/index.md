[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [OnFileInsurance](./index.md)

# OnFileInsurance

`class OnFileInsurance : `[`InsuranceInfo`](../-insurance-info/index.md)

PaymentMethod for use when the insurance is already on file

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when the insurance is already on file`OnFileInsurance()` |
