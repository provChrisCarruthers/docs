[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [OnFileInsurance](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`OnFileInsurance()`

PaymentMethod for use when the insurance is already on file

