[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfImageInsurance](./index.md)

# SelfImageInsurance

`class SelfImageInsurance : `[`InsuranceInfo`](../-insurance-info/index.md)

PaymentMethod for use when images of the front and back of the insurance card have been uploaded
using the RetailService.uploadInsuranceCard method

### Parameters

`insuranceCardURL` - the URL as returned by RetailService.uploadInsuranceCard

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | PaymentMethod for use when images of the front and back of the insurance card have been uploaded using the RetailService.uploadInsuranceCard method`SelfImageInsurance(insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |
