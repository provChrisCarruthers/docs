[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [SelfImageInsurance](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`SelfImageInsurance(insuranceCardURL: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

PaymentMethod for use when images of the front and back of the insurance card have been uploaded
using the RetailService.uploadInsuranceCard method

### Parameters

`insuranceCardURL` - the URL as returned by RetailService.uploadInsuranceCard