[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayer](index.md) / [payerId](./payer-id.md)

# payerId

`val payerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)