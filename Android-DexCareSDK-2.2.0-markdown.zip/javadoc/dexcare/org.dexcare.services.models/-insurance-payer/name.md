[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayer](index.md) / [name](./name.md)

# name

`val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)