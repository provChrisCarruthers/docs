[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayer](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`InsurancePayer(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, payerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`