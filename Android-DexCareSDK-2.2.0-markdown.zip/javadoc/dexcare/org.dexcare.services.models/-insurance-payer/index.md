[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [InsurancePayer](./index.md)

# InsurancePayer

`data class InsurancePayer`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `InsurancePayer(name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, payerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [name](name.md) | `val name: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [payerId](payer-id.md) | `val payerId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
