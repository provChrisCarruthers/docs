[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentHolderDeclaration](index.md) / [Other](./-other.md)

# Other

`Other`