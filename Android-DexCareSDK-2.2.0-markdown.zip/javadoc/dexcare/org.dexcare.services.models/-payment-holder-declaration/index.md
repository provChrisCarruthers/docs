[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentHolderDeclaration](./index.md)

# PaymentHolderDeclaration

`enum class PaymentHolderDeclaration`

### Enum Values

| Name | Summary |
|---|---|
| [Self](-self.md) |  |
| [Other](-other.md) |  |

### Properties

| Name | Summary |
|---|---|
| [holder](holder.md) | `val holder: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
