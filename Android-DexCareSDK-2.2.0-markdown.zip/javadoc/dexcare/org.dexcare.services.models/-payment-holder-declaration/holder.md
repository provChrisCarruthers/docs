[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentHolderDeclaration](index.md) / [holder](./holder.md)

# holder

`val holder: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)