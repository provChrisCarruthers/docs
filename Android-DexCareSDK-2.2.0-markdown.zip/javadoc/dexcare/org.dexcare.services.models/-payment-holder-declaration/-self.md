[dexcare](../../index.md) / [org.dexcare.services.models](../index.md) / [PaymentHolderDeclaration](index.md) / [Self](./-self.md)

# Self

`Self`