[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](index.md) / [appointmentId](./appointment-id.md)

# appointmentId

`val appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)