[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](./index.md)

# Appointment

`data class ~~Appointment~~`
**Deprecated:** Replaced with ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Appointment(appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, status: `[`AppointmentStatus`](../-appointment-status/index.md)`, startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, reasonForVisit: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, clinicInfo: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [appointmentId](appointment-id.md) | `val appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [clinicInfo](clinic-info.md) | `val clinicInfo: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md) |
| [ehrSystemName](ehr-system-name.md) | `val ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [endTime](end-time.md) | `val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [patientId](patient-id.md) | `val patientId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [reasonForVisit](reason-for-visit.md) | `val reasonForVisit: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [startTime](start-time.md) | `val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [status](status.md) | `val status: `[`AppointmentStatus`](../-appointment-status/index.md) |
