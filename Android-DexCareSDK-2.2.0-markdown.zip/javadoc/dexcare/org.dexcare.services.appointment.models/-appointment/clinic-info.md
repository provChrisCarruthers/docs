[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](index.md) / [clinicInfo](./clinic-info.md)

# clinicInfo

`val clinicInfo: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)