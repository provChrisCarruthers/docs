[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](index.md) / [ehrSystemName](./ehr-system-name.md)

# ehrSystemName

`val ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)