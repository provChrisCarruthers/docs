[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](index.md) / [status](./status.md)

# status

`val status: `[`AppointmentStatus`](../-appointment-status/index.md)