[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Appointment](index.md) / [reasonForVisit](./reason-for-visit.md)

# reasonForVisit

`val reasonForVisit: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)