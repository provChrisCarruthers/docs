[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [CancelReason](index.md) / [displayText](./display-text.md)

# displayText

`val displayText: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

A string that should be displayed to the user

### Property

`displayText` - A string that should be displayed to the user