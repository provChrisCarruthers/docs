[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [CancelReason](index.md) / [code](./code.md)

# code

`val code: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The code that should be passed through for the reason for cancelling

### Property

`code` - The code that should be passed through for the reason for cancelling