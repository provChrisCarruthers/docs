[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [CancelReason](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`CancelReason(displayText: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, code: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

Contains details about a reason for a person to cancel an appointment. These are based on brand

