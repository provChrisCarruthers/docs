[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [CancelReason](./index.md)

# CancelReason

`data class CancelReason`

Contains details about a reason for a person to cancel an appointment. These are based on brand

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Contains details about a reason for a person to cancel an appointment. These are based on brand`CancelReason(displayText: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, code: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [code](code.md) | The code that should be passed through for the reason for cancelling`val code: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [displayText](display-text.md) | A string that should be displayed to the user`val displayText: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
