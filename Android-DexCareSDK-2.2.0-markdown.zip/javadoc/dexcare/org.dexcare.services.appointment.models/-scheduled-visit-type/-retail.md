[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitType](index.md) / [Retail](./-retail.md)

# Retail

`Retail`