[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitType](index.md) / [Unknown](./-unknown.md)

# Unknown

`Unknown`