[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitType](./index.md)

# ScheduledVisitType

`enum class ScheduledVisitType`

An enum representing the type of a ScheduledVisit: Retail, Virtual, or At Home.

**See Also**

[ScheduledVisit](../-scheduled-visit/index.md)

### Enum Values

| Name | Summary |
|---|---|
| [AtHome](-at-home.md) |  |
| [Retail](-retail.md) |  |
| [Virtual](-virtual.md) |  |
| [Unknown](-unknown.md) |  |

### Properties

| Name | Summary |
|---|---|
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
