[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitType](index.md) / [Virtual](./-virtual.md)

# Virtual

`Virtual`