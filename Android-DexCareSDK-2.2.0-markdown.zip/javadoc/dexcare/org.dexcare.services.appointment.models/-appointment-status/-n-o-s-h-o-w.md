[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentStatus](index.md) / [NOSHOW](./-n-o-s-h-o-w.md)

# NOSHOW

`NOSHOW`