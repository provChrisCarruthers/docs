[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentStatus](index.md) / [CANCELED](./-c-a-n-c-e-l-e-d.md)

# CANCELED

`CANCELED`