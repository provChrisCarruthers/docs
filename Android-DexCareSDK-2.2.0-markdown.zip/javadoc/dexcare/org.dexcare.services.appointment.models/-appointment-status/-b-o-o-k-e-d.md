[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentStatus](index.md) / [BOOKED](./-b-o-o-k-e-d.md)

# BOOKED

`BOOKED`