[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentStatus](./index.md)

# AppointmentStatus

`enum class ~~AppointmentStatus~~`
**Deprecated:** Replaced with ScheduledVisit

### Enum Values

| Name | Summary |
|---|---|
| [BOOKED](-b-o-o-k-e-d.md) |  |
| [CANCELED](-c-a-n-c-e-l-e-d.md) |  |
| [NOSHOW](-n-o-s-h-o-w.md) |  |

### Properties

| Name | Summary |
|---|---|
| [status](status.md) | `val status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
