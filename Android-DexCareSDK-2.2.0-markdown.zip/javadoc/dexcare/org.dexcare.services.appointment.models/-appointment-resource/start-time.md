[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [startTime](./start-time.md)

# startTime

`val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)