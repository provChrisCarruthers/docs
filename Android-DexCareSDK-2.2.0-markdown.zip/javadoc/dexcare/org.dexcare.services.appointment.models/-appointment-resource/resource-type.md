[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [resourceType](./resource-type.md)

# resourceType

`val resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)