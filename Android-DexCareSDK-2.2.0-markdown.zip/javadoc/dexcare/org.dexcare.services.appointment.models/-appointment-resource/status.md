[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [status](./status.md)

# status

`val status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)