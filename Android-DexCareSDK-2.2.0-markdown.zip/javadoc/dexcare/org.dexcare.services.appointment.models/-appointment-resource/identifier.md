[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [identifier](./identifier.md)

# identifier

`val identifier: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../-identifier/index.md)`>`