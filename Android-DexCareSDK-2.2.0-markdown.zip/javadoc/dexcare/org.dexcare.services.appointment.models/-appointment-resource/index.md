[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](./index.md)

# AppointmentResource

`data class ~~AppointmentResource~~`
**Deprecated:** Replaced with ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `AppointmentResource(resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, identifier: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../-identifier/index.md)`> = listOf(), status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, comment: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", participants: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Participant`](../-participant/index.md)`> = listOf())` |

### Properties

| Name | Summary |
|---|---|
| [comment](comment.md) | `val comment: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [endTime](end-time.md) | `val endTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [identifier](identifier.md) | `val identifier: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Identifier`](../-identifier/index.md)`>` |
| [participants](participants.md) | `val participants: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Participant`](../-participant/index.md)`>` |
| [resourceType](resource-type.md) | `val resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [startTime](start-time.md) | `val startTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [status](status.md) | `val status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
