[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [comment](./comment.md)

# comment

`val comment: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)