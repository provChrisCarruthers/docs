[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentResource](index.md) / [participants](./participants.md)

# participants

`val participants: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`Participant`](../-participant/index.md)`>`