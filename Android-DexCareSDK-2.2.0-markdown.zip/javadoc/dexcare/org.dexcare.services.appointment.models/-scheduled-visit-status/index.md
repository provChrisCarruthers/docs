[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](./index.md)

# ScheduledVisitStatus

`enum class ScheduledVisitStatus`

An enum representing the current status of a ScheduledVisit

**See Also**

[ScheduledVisit](../-scheduled-visit/index.md)

### Enum Values

| Name | Summary |
|---|---|
| [Requested](-requested.md) |  |
| [WaitingRoom](-waiting-room.md) |  |
| [InVisit](-in-visit.md) |  |
| [StaffDeclined](-staff-declined.md) |  |
| [Verification](-verification.md) |  |
| [Cancelled](-cancelled.md) |  |
| [Done](-done.md) |  |
| [Unknown](-unknown.md) |  |

### Properties

| Name | Summary |
|---|---|
| [status](status.md) | `val status: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
