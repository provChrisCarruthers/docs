[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [WaitingRoom](./-waiting-room.md)

# WaitingRoom

`WaitingRoom`