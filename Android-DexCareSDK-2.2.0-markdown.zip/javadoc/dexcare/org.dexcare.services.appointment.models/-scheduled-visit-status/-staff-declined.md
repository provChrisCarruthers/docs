[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [StaffDeclined](./-staff-declined.md)

# StaffDeclined

`StaffDeclined`