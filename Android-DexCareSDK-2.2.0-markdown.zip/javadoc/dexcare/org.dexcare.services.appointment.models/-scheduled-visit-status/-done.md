[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [Done](./-done.md)

# Done

`Done`