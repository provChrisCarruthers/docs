[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [Verification](./-verification.md)

# Verification

`Verification`