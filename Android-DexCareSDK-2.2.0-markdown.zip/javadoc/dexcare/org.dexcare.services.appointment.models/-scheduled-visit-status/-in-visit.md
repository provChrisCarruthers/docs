[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [InVisit](./-in-visit.md)

# InVisit

`InVisit`