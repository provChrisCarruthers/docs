[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [Cancelled](./-cancelled.md)

# Cancelled

`Cancelled`