[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisitStatus](index.md) / [Unknown](./-unknown.md)

# Unknown

`Unknown`