[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentEntry](./index.md)

# AppointmentEntry

`data class ~~AppointmentEntry~~`
**Deprecated:** Replaced with ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `AppointmentEntry(resource: `[`AppointmentResource`](../-appointment-resource/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [resource](resource.md) | `val resource: `[`AppointmentResource`](../-appointment-resource/index.md) |
