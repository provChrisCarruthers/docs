[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentEntry](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`AppointmentEntry(resource: `[`AppointmentResource`](../-appointment-resource/index.md)`)`