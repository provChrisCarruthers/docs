[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentEntry](index.md) / [resource](./resource.md)

# resource

`val resource: `[`AppointmentResource`](../-appointment-resource/index.md)