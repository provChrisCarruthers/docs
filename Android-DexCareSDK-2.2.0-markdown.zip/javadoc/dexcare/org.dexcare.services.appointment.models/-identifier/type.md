[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Identifier](index.md) / [type](./type.md)

# type

`val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)