[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Identifier](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Identifier(system: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "")`