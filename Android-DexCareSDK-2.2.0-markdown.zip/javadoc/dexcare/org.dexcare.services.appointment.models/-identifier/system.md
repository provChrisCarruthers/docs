[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Identifier](index.md) / [system](./system.md)

# system

`val system: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)