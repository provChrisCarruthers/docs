[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Identifier](index.md) / [value](./value.md)

# value

`val value: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)