[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [patientPhone](./patient-phone.md)

# patientPhone

`val patientPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`

The patient's contact phone number

### Property

`patientPhone` - The patient's contact phone number