[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [endDateTime](./end-date-time.md)

# endDateTime

`val endDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

The end time of the appointment, in the timezone of the appointment

### Property

`endDateTime` - The end time of the appointment, in the timezone of the appointment