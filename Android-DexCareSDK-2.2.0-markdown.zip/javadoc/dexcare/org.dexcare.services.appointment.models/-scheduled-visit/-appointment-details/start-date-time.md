[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [startDateTime](./start-date-time.md)

# startDateTime

`val startDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)

The start time of the appointment, in the timezone of the appointment

### Property

`startDateTime` - The start time of the appointment, in the timezone of the appointment