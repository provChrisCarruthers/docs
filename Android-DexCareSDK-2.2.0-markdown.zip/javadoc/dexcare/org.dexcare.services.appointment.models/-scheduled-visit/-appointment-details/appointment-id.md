[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [appointmentId](./appointment-id.md)

# appointmentId

`val appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

A unique identifier representing this appointment

### Property

`appointmentId` - A unique identifier representing this appointment