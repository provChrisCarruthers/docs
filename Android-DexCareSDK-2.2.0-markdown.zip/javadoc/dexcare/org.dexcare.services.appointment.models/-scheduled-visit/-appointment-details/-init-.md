[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`AppointmentDetails(appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, endDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, startDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`

Contains details about a specific ScheduledVisit appointment.

