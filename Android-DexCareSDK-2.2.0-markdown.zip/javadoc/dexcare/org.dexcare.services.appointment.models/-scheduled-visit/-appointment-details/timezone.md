[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [timezone](./timezone.md)

# timezone

`val timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The timezone the appointment is scheduled in

### Property

`timezone` - The timezone the appointment is scheduled in

**See Also**

[ScheduledVisit](../index.md)

