[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](index.md) / [slotId](./slot-id.md)

# slotId

`val slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

An encoded representation of the appointment's time slot

### Property

`slotId` - An encoded representation of the appointment's time slot