[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [AppointmentDetails](./index.md)

# AppointmentDetails

`data class AppointmentDetails`

Contains details about a specific ScheduledVisit appointment.

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Contains details about a specific ScheduledVisit appointment.`AppointmentDetails(appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, endDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, startDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`, timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [appointmentId](appointment-id.md) | A unique identifier representing this appointment`val appointmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [endDateTime](end-date-time.md) | The end time of the appointment, in the timezone of the appointment`val endDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [slotId](slot-id.md) | An encoded representation of the appointment's time slot`val slotId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [startDateTime](start-date-time.md) | The start time of the appointment, in the timezone of the appointment`val startDateTime: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html) |
| [timezone](timezone.md) | The timezone the appointment is scheduled in`val timezone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
