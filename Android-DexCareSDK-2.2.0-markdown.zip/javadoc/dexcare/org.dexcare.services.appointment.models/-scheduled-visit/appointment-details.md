[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [appointmentDetails](./appointment-details.md)

# appointmentDetails

`val appointmentDetails: AppointmentDetails`

An object containing additional details about the appointment

### Property

`appointmentDetails` - An object containing additional details about the appointment