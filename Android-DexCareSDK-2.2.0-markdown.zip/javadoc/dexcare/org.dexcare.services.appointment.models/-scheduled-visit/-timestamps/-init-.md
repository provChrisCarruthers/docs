[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [Timestamps](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Timestamps(cancelled: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, done: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, requested: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, staffdeclined: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?)`

Contains various times at which a ScheduledVisit's status was updated

