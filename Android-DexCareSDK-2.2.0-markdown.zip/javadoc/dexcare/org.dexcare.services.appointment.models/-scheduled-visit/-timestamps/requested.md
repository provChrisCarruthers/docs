[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [Timestamps](index.md) / [requested](./requested.md)

# requested

`val requested: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?`

The day and time at which the visit was requested

### Property

`requested` - The day and time at which the visit was requested