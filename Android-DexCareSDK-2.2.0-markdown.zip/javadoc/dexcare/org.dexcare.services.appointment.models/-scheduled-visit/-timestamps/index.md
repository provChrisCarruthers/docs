[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [Timestamps](./index.md)

# Timestamps

`data class Timestamps`

Contains various times at which a ScheduledVisit's status was updated

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Contains various times at which a ScheduledVisit's status was updated`Timestamps(cancelled: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, done: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, requested: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?, staffdeclined: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?)` |

### Properties

| Name | Summary |
|---|---|
| [cancelled](cancelled.md) | The day and time at which the visit was cancelled`val cancelled: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?` |
| [done](done.md) | The day and time at which the visit was completed`val done: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?` |
| [requested](requested.md) | The day and time at which the visit was requested`val requested: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?` |
| [staffdeclined](staffdeclined.md) | The day and time at which the visit was declined by staff`val staffdeclined: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?` |
