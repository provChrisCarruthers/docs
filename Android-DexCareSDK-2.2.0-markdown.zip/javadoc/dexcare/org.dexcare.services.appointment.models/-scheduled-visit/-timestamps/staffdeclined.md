[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [Timestamps](index.md) / [staffdeclined](./staffdeclined.md)

# staffdeclined

`val staffdeclined: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?`

The day and time at which the visit was declined by staff

### Property

`staffdeclined` - The day and time at which the visit was declined by staff

**See Also**

[ScheduledVisit](../index.md)

