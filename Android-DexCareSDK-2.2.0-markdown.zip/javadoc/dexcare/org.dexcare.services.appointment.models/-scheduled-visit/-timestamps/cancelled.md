[dexcare](../../../index.md) / [org.dexcare.services.appointment.models](../../index.md) / [ScheduledVisit](../index.md) / [Timestamps](index.md) / [cancelled](./cancelled.md)

# cancelled

`val cancelled: `[`Date`](https://docs.oracle.com/javase/6/docs/api/java/util/Date.html)`?`

The day and time at which the visit was cancelled

### Property

`cancelled` - The day and time at which the visit was cancelled