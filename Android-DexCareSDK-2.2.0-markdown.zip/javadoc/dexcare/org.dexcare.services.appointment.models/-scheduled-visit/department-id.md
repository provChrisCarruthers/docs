[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [departmentId](./department-id.md)

# departmentId

`val departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The ID of the department where the visit is scheduled

### Property

`departmentId` - The ID of the department where the visit is scheduled