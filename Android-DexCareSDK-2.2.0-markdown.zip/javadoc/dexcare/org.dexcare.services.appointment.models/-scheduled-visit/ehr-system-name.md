[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [ehrSystemName](./ehr-system-name.md)

# ehrSystemName

`val ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The ehrSystem in which the visit is scheduled

### Property

`ehrSystemName` - The ehrSystem in which the visit is scheduled