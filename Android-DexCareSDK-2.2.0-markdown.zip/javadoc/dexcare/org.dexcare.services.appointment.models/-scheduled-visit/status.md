[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [status](./status.md)

# status

`val status: `[`ScheduledVisitStatus`](../-scheduled-visit-status/index.md)

An enum representing the current status of the visit

### Property

`status` - An enum representing the current status of the visit