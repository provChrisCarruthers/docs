[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`ScheduledVisit(address: `[`Address`](../../org.dexcare.services.patient.models/-address/index.md)`, appointmentDetails: AppointmentDetails, departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, id: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, isNewPatient: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, isReadyForVisit: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, patientEmail: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, status: `[`ScheduledVisitStatus`](../-scheduled-visit-status/index.md)`, timestamps: Timestamps, type: `[`ScheduledVisitType`](../-scheduled-visit-type/index.md)`, clinic: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`? = null)`

Contains details about an upcoming scheduled visit.

