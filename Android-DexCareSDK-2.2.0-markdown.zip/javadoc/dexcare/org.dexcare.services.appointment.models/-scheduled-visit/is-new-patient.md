[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [isNewPatient](./is-new-patient.md)

# isNewPatient

`val isNewPatient: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

A flag to indicate if a new patient record was created or not for a visit

### Property

`isNewPatient` - A flag to indicate if a new patient record was created or not for a visit