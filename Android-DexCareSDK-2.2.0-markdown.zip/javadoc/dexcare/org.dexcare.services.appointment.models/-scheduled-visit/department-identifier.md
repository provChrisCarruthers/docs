[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [departmentIdentifier](./department-identifier.md)

# departmentIdentifier

`val departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)