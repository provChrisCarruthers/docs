[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [patientEmail](./patient-email.md)

# patientEmail

`val patientEmail: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?`

The patient's contact email

### Property

`patientEmail` - The patient's contact email