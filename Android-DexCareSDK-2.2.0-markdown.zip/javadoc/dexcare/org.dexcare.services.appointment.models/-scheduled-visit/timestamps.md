[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [timestamps](./timestamps.md)

# timestamps

`val timestamps: Timestamps`

An object containing specific dateTimes indicating when the visit was updated

### Property

`timestamps` - An object containing specific dateTimes indicating when the visit was updated