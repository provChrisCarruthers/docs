[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [id](./id.md)

# id

`val id: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

A unique identifier representing this visit.  This is not the same as the appointment's id.

### Property

`id` - A unique identifier representing this visit.  This is not the same as the appointment's id.