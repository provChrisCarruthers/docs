[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [isReadyForVisit](./is-ready-for-visit.md)

# isReadyForVisit

`val isReadyForVisit: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

A flag to indicate whether a PRR or a provider indicates that the visit is ready to happen

### Property

`isReadyForVisit` - A flag to indicate whether a PRR or a provider indicates that the visit is ready to happen