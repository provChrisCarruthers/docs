[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [address](./address.md)

# address

`val address: `[`Address`](../../org.dexcare.services.patient.models/-address/index.md)

The patient's address

### Property

`address` - The patient's address