[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [patientGuid](./patient-guid.md)

# patientGuid

`val patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)

The unique identifier representing a DexCare Patient

### Property

`patientGuid` - The unique identifier representing a DexCare Patient