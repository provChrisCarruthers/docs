[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](./index.md)

# ScheduledVisit

`data class ScheduledVisit`

Contains details about an upcoming scheduled visit.

### Types

| Name | Summary |
|---|---|
| [AppointmentDetails](-appointment-details/index.md) | Contains details about a specific ScheduledVisit appointment.`data class AppointmentDetails` |
| [Timestamps](-timestamps/index.md) | Contains various times at which a ScheduledVisit's status was updated`data class Timestamps` |

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Contains details about an upcoming scheduled visit.`ScheduledVisit(address: `[`Address`](../../org.dexcare.services.patient.models/-address/index.md)`, appointmentDetails: AppointmentDetails, departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, id: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, isNewPatient: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, isReadyForVisit: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)`, patientEmail: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, patientPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null, status: `[`ScheduledVisitStatus`](../-scheduled-visit-status/index.md)`, timestamps: Timestamps, type: `[`ScheduledVisitType`](../-scheduled-visit-type/index.md)`, clinic: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`? = null)` |

### Properties

| Name | Summary |
|---|---|
| [address](address.md) | The patient's address`val address: `[`Address`](../../org.dexcare.services.patient.models/-address/index.md) |
| [appointmentDetails](appointment-details.md) | An object containing additional details about the appointment`val appointmentDetails: AppointmentDetails` |
| [clinic](clinic.md) | An object containing information about the clinic where the visit was scheduled.  Present only for Retail visit type, null otherwise.`val clinic: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`?` |
| [departmentId](department-id.md) | The ID of the department where the visit is scheduled`val departmentId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [departmentIdentifier](department-identifier.md) | `val departmentIdentifier: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [ehrSystemName](ehr-system-name.md) | The ehrSystem in which the visit is scheduled`val ehrSystemName: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [id](id.md) | A unique identifier representing this visit.  This is not the same as the appointment's id.`val id: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [isNewPatient](is-new-patient.md) | A flag to indicate if a new patient record was created or not for a visit`val isNewPatient: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) |
| [isReadyForVisit](is-ready-for-visit.md) | A flag to indicate whether a PRR or a provider indicates that the visit is ready to happen`val isReadyForVisit: `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) |
| [patientEmail](patient-email.md) | The patient's contact email`val patientEmail: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [patientGuid](patient-guid.md) | The unique identifier representing a DexCare Patient`val patientGuid: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [patientPhone](patient-phone.md) | The patient's contact phone number`val patientPhone: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`?` |
| [status](status.md) | An enum representing the current status of the visit`val status: `[`ScheduledVisitStatus`](../-scheduled-visit-status/index.md) |
| [timestamps](timestamps.md) | An object containing specific dateTimes indicating when the visit was updated`val timestamps: Timestamps` |
| [type](type.md) | The type of visit: Retail, Virtual or At Home`val type: `[`ScheduledVisitType`](../-scheduled-visit-type/index.md) |
