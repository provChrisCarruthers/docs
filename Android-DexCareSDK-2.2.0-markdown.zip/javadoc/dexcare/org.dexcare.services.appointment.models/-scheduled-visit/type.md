[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [type](./type.md)

# type

`val type: `[`ScheduledVisitType`](../-scheduled-visit-type/index.md)

The type of visit: Retail, Virtual or At Home

### Property

`type` - The type of visit: Retail, Virtual or At Home