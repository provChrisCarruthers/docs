[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [ScheduledVisit](index.md) / [clinic](./clinic.md)

# clinic

`val clinic: `[`Clinic`](../../org.dexcare.services.retail.models/-clinic/index.md)`?`

An object containing information about the clinic where the visit was scheduled.  Present only for Retail visit type, null otherwise.

### Property

`clinic` - An object containing information about the clinic where the visit was scheduled.  Present only for Retail visit type, null otherwise.

**See Also**

[org.dexcare.services.appointment.AppointmentService](../../org.dexcare.services.appointment/-appointment-service/index.md)

