[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentsBundle](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`AppointmentsBundle(resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, total: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, entry: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`AppointmentEntry`](../-appointment-entry/index.md)`> = listOf())`