[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentsBundle](index.md) / [total](./total.md)

# total

`val total: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)