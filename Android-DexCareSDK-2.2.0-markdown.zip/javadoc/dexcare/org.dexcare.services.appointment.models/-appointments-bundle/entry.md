[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentsBundle](index.md) / [entry](./entry.md)

# entry

`val entry: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`AppointmentEntry`](../-appointment-entry/index.md)`>`