[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [AppointmentsBundle](./index.md)

# AppointmentsBundle

`data class ~~AppointmentsBundle~~`
**Deprecated:** Replaced with ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `AppointmentsBundle(resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, total: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)`, entry: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`AppointmentEntry`](../-appointment-entry/index.md)`> = listOf())` |

### Properties

| Name | Summary |
|---|---|
| [entry](entry.md) | `val entry: `[`List`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin.collections/-list/index.html)`<`[`AppointmentEntry`](../-appointment-entry/index.md)`>` |
| [resourceType](resource-type.md) | `val resourceType: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [total](total.md) | `val total: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [type](type.md) | `val type: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
