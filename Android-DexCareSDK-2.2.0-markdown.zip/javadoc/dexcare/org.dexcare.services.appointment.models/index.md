[dexcare](../index.md) / [org.dexcare.services.appointment.models](./index.md)

## Package org.dexcare.services.appointment.models

### Types

| Name | Summary |
|---|---|
| [Actor](-actor/index.md) | `data class ~~Actor~~` |
| [Appointment](-appointment/index.md) | `data class ~~Appointment~~` |
| [AppointmentEntry](-appointment-entry/index.md) | `data class ~~AppointmentEntry~~` |
| [AppointmentResource](-appointment-resource/index.md) | `data class ~~AppointmentResource~~` |
| [AppointmentsBundle](-appointments-bundle/index.md) | `data class ~~AppointmentsBundle~~` |
| [AppointmentStatus](-appointment-status/index.md) | `enum class ~~AppointmentStatus~~` |
| [CancelReason](-cancel-reason/index.md) | Contains details about a reason for a person to cancel an appointment. These are based on brand`data class CancelReason` |
| [Identifier](-identifier/index.md) | `data class Identifier : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
| [Participant](-participant/index.md) | `data class ~~Participant~~` |
| [ScheduledVisit](-scheduled-visit/index.md) | Contains details about an upcoming scheduled visit.`data class ScheduledVisit` |
| [ScheduledVisitStatus](-scheduled-visit-status/index.md) | An enum representing the current status of a ScheduledVisit`enum class ScheduledVisitStatus` |
| [ScheduledVisitType](-scheduled-visit-type/index.md) | An enum representing the type of a ScheduledVisit: Retail, Virtual, or At Home.`enum class ScheduledVisitType` |
