[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Actor](index.md) / [display](./display.md)

# display

`val display: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)