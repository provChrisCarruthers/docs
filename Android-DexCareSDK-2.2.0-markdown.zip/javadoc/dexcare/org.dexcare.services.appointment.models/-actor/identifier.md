[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Actor](index.md) / [identifier](./identifier.md)

# identifier

`val identifier: `[`Identifier`](../-identifier/index.md)