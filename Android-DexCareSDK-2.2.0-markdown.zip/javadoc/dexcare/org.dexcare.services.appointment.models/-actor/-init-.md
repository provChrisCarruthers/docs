[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Actor](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Actor(reference: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, identifier: `[`Identifier`](../-identifier/index.md)`, display: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`