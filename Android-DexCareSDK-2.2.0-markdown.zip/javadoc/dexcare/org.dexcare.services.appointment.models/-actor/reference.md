[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Actor](index.md) / [reference](./reference.md)

# reference

`val reference: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)