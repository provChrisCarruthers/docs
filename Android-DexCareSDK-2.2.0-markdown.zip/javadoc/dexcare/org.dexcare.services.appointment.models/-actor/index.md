[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Actor](./index.md)

# Actor

`data class ~~Actor~~`
**Deprecated:** Replaced by ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Actor(reference: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`, identifier: `[`Identifier`](../-identifier/index.md)`, display: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |

### Properties

| Name | Summary |
|---|---|
| [display](display.md) | `val display: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
| [identifier](identifier.md) | `val identifier: `[`Identifier`](../-identifier/index.md) |
| [reference](reference.md) | `val reference: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
