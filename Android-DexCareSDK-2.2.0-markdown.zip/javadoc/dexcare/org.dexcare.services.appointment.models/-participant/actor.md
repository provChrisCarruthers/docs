[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Participant](index.md) / [actor](./actor.md)

# actor

`val actor: `[`Actor`](../-actor/index.md)