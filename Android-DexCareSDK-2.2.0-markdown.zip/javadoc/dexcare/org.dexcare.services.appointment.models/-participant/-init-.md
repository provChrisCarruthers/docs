[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Participant](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`Participant(actor: `[`Actor`](../-actor/index.md)`)`