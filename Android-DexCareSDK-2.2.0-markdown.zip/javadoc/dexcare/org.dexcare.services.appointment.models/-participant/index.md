[dexcare](../../index.md) / [org.dexcare.services.appointment.models](../index.md) / [Participant](./index.md)

# Participant

`data class ~~Participant~~`
**Deprecated:** Replaced by ScheduledVisit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `Participant(actor: `[`Actor`](../-actor/index.md)`)` |

### Properties

| Name | Summary |
|---|---|
| [actor](actor.md) | `val actor: `[`Actor`](../-actor/index.md) |
