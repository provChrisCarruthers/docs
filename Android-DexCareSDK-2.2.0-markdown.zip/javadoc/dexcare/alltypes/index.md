

### All Types

| Name | Summary |
|---|---|
|

##### [org.dexcare.services.appointment.models.Actor](../org.dexcare.services.appointment.models/-actor/index.md)


|

##### [org.dexcare.services.models.Actor](../org.dexcare.services.models/-actor/index.md)


|

##### [org.dexcare.services.patient.models.Address](../org.dexcare.services.patient.models/-address/index.md)


|

##### [org.dexcare.services.retail.models.AllowedVisitType](../org.dexcare.services.retail.models/-allowed-visit-type/index.md)


|

##### [org.dexcare.services.retail.errors.AlreadyBookedAtSameTimeError](../org.dexcare.services.retail.errors/-already-booked-at-same-time-error/index.md)

This error indicates the user has already booked another appointment at the same time


|

##### [org.dexcare.services.virtualvisit.models.Answer](../org.dexcare.services.virtualvisit.models/-answer/index.md)


|

##### [org.dexcare.services.appointment.models.Appointment](../org.dexcare.services.appointment.models/-appointment/index.md)


|

##### [org.dexcare.services.appointment.models.AppointmentEntry](../org.dexcare.services.appointment.models/-appointment-entry/index.md)


|

##### [org.dexcare.services.appointment.models.AppointmentResource](../org.dexcare.services.appointment.models/-appointment-resource/index.md)


|

##### [org.dexcare.services.appointment.models.AppointmentsBundle](../org.dexcare.services.appointment.models/-appointments-bundle/index.md)


|

##### [org.dexcare.services.appointment.AppointmentService](../org.dexcare.services.appointment/-appointment-service/index.md)


|

##### [org.dexcare.services.appointment.models.AppointmentStatus](../org.dexcare.services.appointment.models/-appointment-status/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.uiviews.AutoFitTextureView](../org.dexcare.services.virtualvisit.video.fragment.uiviews/-auto-fit-texture-view/index.md)

A [TextureView](https://developer.android.com/reference/android/view/TextureView.html) that can be adjusted to a specified aspect ratio.


|

##### [org.dexcare.services.virtualvisit.models.Availability](../org.dexcare.services.virtualvisit.models/-availability/index.md)


|

##### [org.dexcare.dal.errorHandling.retries.BaseRetry](../org.dexcare.dal.error-handling.retries/-base-retry/index.md)

This provides an interface to implement a retrywhen for flowables


|

##### [org.dexcare.services.virtualvisit.video.fragment.uiviews.BetterLinkify](../org.dexcare.services.virtualvisit.video.fragment.uiviews/-better-linkify/index.md)


| (extensions in package org.dexcare.exts)

##### [android.graphics.Bitmap](../org.dexcare.exts/android.graphics.-bitmap/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.uiviews.CameraPreview](../org.dexcare.services.virtualvisit.video.fragment.uiviews/-camera-preview/index.md)


|

##### [org.dexcare.services.appointment.models.CancelReason](../org.dexcare.services.appointment.models/-cancel-reason/index.md)

Contains details about a reason for a person to cancel an appointment. These are based on brand


|

##### [org.dexcare.services.retail.models.Clinic](../org.dexcare.services.retail.models/-clinic/index.md)


|

##### [org.dexcare.services.retail.models.ClinicTimeSlot](../org.dexcare.services.retail.models/-clinic-time-slot/index.md)

Represents a grouping of time slots for a particular Retail clinic


| (extensions in package org.dexcare.dal.exts)

##### [io.reactivex.Completable](../org.dexcare.dal.exts/io.reactivex.-completable/index.md)


| (extensions in package org.dexcare.exts)

##### [io.reactivex.Completable](../org.dexcare.exts/io.reactivex.-completable/index.md)


|

##### [org.dexcare.services.virtualvisit.models.Conference](../org.dexcare.services.virtualvisit.models/-conference/index.md)


| (extensions in package org.dexcare.dal.exts)

##### [android.content.Context](../org.dexcare.dal.exts/android.content.-context/index.md)


|

##### [org.dexcare.services.virtualvisit.models.CouponCode](../org.dexcare.services.virtualvisit.models/-coupon-code/index.md)


|

##### [org.dexcare.services.models.CouponCodeInfo](../org.dexcare.services.models/-coupon-code-info/index.md)

PaymentMethod for use when a service key has been applied


|

##### [org.dexcare.services.models.CreditCardInfo](../org.dexcare.services.models/-credit-card-info/index.md)

PaymentMethod for use with credit card payments.  Requires stripe library
https://stripe.com/docs/mobile/android/basic


|

##### [org.dexcare.dal.errorHandling.errors.DalNotInitError](../org.dexcare.dal.error-handling.errors/-dal-not-init-error/index.md)


|

##### [org.dexcare.dal.DataObserver](../org.dexcare.dal/-data-observer/index.md)

Public facing interface for users to grab data


| (extensions in package org.dexcare.exts)

##### [java.util.Date](../org.dexcare.exts/java.util.-date/index.md)


|

##### [org.dexcare.services.pcp.models.Department](../org.dexcare.services.pcp.models/-department/index.md)


|

##### [org.dexcare.services.patient.models.DexCarePatient](../org.dexcare.services.patient.models/-dex-care-patient/index.md)


|

##### [org.dexcare.DexCareSDK](../org.dexcare/-dex-care-s-d-k/index.md)

This is the public facing interface for clients to be using for DexCare


|

##### [org.dexcare.Environment](../org.dexcare/-environment/index.md)


|

##### [org.dexcare.services.retail.errors.FailedToBookError](../org.dexcare.services.retail.errors/-failed-to-book-error/index.md)

This is a general error for when the user is unable to book an appointment


|

##### [org.dexcare.services.virtualvisit.models.Feedback](../org.dexcare.services.virtualvisit.models/-feedback/index.md)


|

##### [org.dexcare.services.virtualvisit.models.FeedbackData](../org.dexcare.services.virtualvisit.models/-feedback-data/index.md)


|

##### [org.dexcare.services.virtualvisit.FhirOrchVirtualVisitContract](../org.dexcare.services.virtualvisit/-fhir-orch-virtual-visit-contract/index.md)


| (extensions in package org.dexcare.dal.exts)

##### [io.reactivex.Flowable](../org.dexcare.dal.exts/io.reactivex.-flowable/index.md)


|

##### [org.dexcare.services.patient.models.Gender](../org.dexcare.services.patient.models/-gender/index.md)


|

##### [org.dexcare.dal.errorHandling.retries.GeneralRetry](../org.dexcare.dal.error-handling.retries/-general-retry/index.md)


|

##### [org.dexcare.dal.network.HeaderContract](../org.dexcare.dal.network/-header-contract/index.md)


| (extensions in package org.dexcare.exts)

##### [retrofit2.HttpException](../org.dexcare.exts/retrofit2.-http-exception/index.md)


|

##### [org.dexcare.dal.errorHandling.retries.HttpRetry](../org.dexcare.dal.error-handling.retries/-http-retry/index.md)

This is an implementation to catch network exceptions for retrywhen


|

##### [org.dexcare.services.patient.models.HumanName](../org.dexcare.services.patient.models/-human-name/index.md)


|

##### [org.dexcare.services.appointment.models.Identifier](../org.dexcare.services.appointment.models/-identifier/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.InstantMessage](../org.dexcare.services.virtualvisit.video.models.signaling/-instant-message/index.md)


|

##### [org.dexcare.services.models.InsuranceInfo](../org.dexcare.services.models/-insurance-info/index.md)


|

##### [org.dexcare.services.models.InsurancePayer](../org.dexcare.services.models/-insurance-payer/index.md)


|

##### [org.dexcare.services.models.InsurancePayers](../org.dexcare.services.models/-insurance-payers/index.md)


|

##### [org.dexcare.services.patient.errors.InvalidPatientDemographicsObjectError](../org.dexcare.services.patient.errors/-invalid-patient-demographics-object-error/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.uiviews.LinkClickListener](../org.dexcare.services.virtualvisit.video.fragment.uiviews/-link-click-listener/index.md)


|

##### [org.dexcare.logs.Logger](../org.dexcare.logs/-logger/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.MessageId](../org.dexcare.services.virtualvisit.video.models.signaling/-message-id/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.viewmodels.MessageItemViewModel](../org.dexcare.services.virtualvisit.video.fragment.viewmodels/-message-item-view-model/index.md)


|

##### [org.dexcare.services.patient.errors.MissingPropertyError](../org.dexcare.services.patient.errors/-missing-property-error/index.md)


|

##### [org.dexcare.services.virtualvisit.errors.NeedPermissionError](../org.dexcare.services.virtualvisit.errors/-need-permission-error/index.md)


|

##### [org.dexcare.services.NetworkError](../org.dexcare.services/-network-error/index.md)

Common http errors


|

##### [org.dexcare.services.virtualvisit.video.fragment.viewmodels.NetworkErrorDialogViewModel](../org.dexcare.services.virtualvisit.video.fragment.viewmodels/-network-error-dialog-view-model/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.viewmodels.NetworkReconnectionDialogViewModel](../org.dexcare.services.virtualvisit.video.fragment.viewmodels/-network-reconnection-dialog-view-model/index.md)


|

##### [org.dexcare.dal.errorHandling.errors.NoBaseUrlSet](../org.dexcare.dal.error-handling.errors/-no-base-url-set/index.md)


|

##### [org.dexcare.services.appointment.errors.NoClinicFoundError](../org.dexcare.services.appointment.errors/-no-clinic-found-error/index.md)


|

##### [org.dexcare.services.patient.errors.NoPatientLinkError](../org.dexcare.services.patient.errors/-no-patient-link-error/index.md)


|

##### [org.dexcare.services.OauthContract](../org.dexcare.services/-oauth-contract/index.md)


|

##### [org.dexcare.services.auth.models.OauthToken](../org.dexcare.services.auth.models/-oauth-token/index.md)


| (extensions in package org.dexcare.dal.exts)

##### [io.reactivex.Observable](../org.dexcare.dal.exts/io.reactivex.-observable/index.md)


|

##### [org.dexcare.services.models.OnFileInsurance](../org.dexcare.services.models/-on-file-insurance/index.md)

PaymentMethod for use when the insurance is already on file


|

##### [org.dexcare.services.retail.models.OpenDay](../org.dexcare.services.retail.models/-open-day/index.md)


|

##### [org.dexcare.services.retail.models.OpenHours](../org.dexcare.services.retail.models/-open-hours/index.md)


|

##### [org.dexcare.services.virtualvisit.models.OperatingHour](../org.dexcare.services.virtualvisit.models/-operating-hour/index.md)


|

##### [org.dexcare.services.appointment.models.Participant](../org.dexcare.services.appointment.models/-participant/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.ParticipantLeftMessage](../org.dexcare.services.virtualvisit.video.models.signaling/-participant-left-message/index.md)


|

##### [org.dexcare.services.models.PatientDeclaration](../org.dexcare.services.models/-patient-declaration/index.md)


|

##### [org.dexcare.services.patient.models.PatientDemographics](../org.dexcare.services.patient.models/-patient-demographics/index.md)


|

##### [org.dexcare.services.patient.models.PatientGuid](../org.dexcare.services.patient.models/-patient-guid/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.PatientInstantMessage](../org.dexcare.services.virtualvisit.video.models.signaling/-patient-instant-message/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.PatientMessageData](../org.dexcare.services.virtualvisit.video.models.signaling/-patient-message-data/index.md)


|

##### [org.dexcare.services.patient.PatientService](../org.dexcare.services.patient/-patient-service/index.md)


|

##### [org.dexcare.services.models.PaymentHolderDeclaration](../org.dexcare.services.models/-payment-holder-declaration/index.md)


|

##### [org.dexcare.services.models.PaymentMethod](../org.dexcare.services.models/-payment-method/index.md)


|

##### [org.dexcare.services.pcp.models.PcpAppointment](../org.dexcare.services.pcp.models/-pcp-appointment/index.md)


|

##### [org.dexcare.services.virtualvisit.models.Prices](../org.dexcare.services.virtualvisit.models/-prices/index.md)


|

##### [org.dexcare.services.pcp.models.Provider](../org.dexcare.services.pcp.models/-provider/index.md)


|

##### [org.dexcare.RefreshTokenContract](../org.dexcare/-refresh-token-contract/index.md)


|

##### [org.dexcare.services.virtualvisit.models.Region](../org.dexcare.services.virtualvisit.models/-region/index.md)


|

##### [org.dexcare.services.virtualvisit.models.RegionAvailability](../org.dexcare.services.virtualvisit.models/-region-availability/index.md)


|

##### [org.dexcare.services.virtualvisit.models.RegionAvailabilityReason](../org.dexcare.services.virtualvisit.models/-region-availability-reason/index.md)


|

##### [org.dexcare.services.virtualvisit.models.RegisterPushNotification](../org.dexcare.services.virtualvisit.models/-register-push-notification/index.md)


|

##### [org.dexcare.services.models.RelationshipToPatient](../org.dexcare.services.models/-relationship-to-patient/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.RemoteMessageTypingState](../org.dexcare.services.virtualvisit.video.models.signaling/-remote-message-typing-state/index.md)


|

##### [org.dexcare.services.retail.RetailService](../org.dexcare.services.retail/-retail-service/index.md)


|

##### [org.dexcare.services.retail.models.RetailVisitInformation](../org.dexcare.services.retail.models/-retail-visit-information/index.md)


|

##### [org.dexcare.services.retail.models.ScheduleDay](../org.dexcare.services.retail.models/-schedule-day/index.md)

Represents a single day of available time slots for a Retail Appointment


|

##### [org.dexcare.services.appointment.models.ScheduledVisit](../org.dexcare.services.appointment.models/-scheduled-visit/index.md)

Contains details about an upcoming scheduled visit.


|

##### [org.dexcare.services.appointment.models.ScheduledVisitStatus](../org.dexcare.services.appointment.models/-scheduled-visit-status/index.md)

An enum representing the current status of a ScheduledVisit


|

##### [org.dexcare.services.appointment.models.ScheduledVisitType](../org.dexcare.services.appointment.models/-scheduled-visit-type/index.md)

An enum representing the type of a ScheduledVisit: Retail, Virtual, or At Home.


|

##### [org.dexcare.services.models.SelfImageInsurance](../org.dexcare.services.models/-self-image-insurance/index.md)

PaymentMethod for use when images of the front and back of the insurance card have been uploaded
using the RetailService.uploadInsuranceCard method


|

##### [org.dexcare.services.models.SelfManualInsurance](../org.dexcare.services.models/-self-manual-insurance/index.md)

PaymentMethod for use when the insurance is owned by the app user.


|

##### [org.dexcare.services.models.SelfPayment](../org.dexcare.services.models/-self-payment/index.md)

PaymentMethod for use when the payment will be provided at the time of visit


|

##### [org.dexcare.services.ServicesContract](../org.dexcare.services/-services-contract/index.md)

Contract for providing services


|

##### [org.dexcare.services.virtualvisit.video.models.SessionInfo](../org.dexcare.services.virtualvisit.video.models/-session-info/index.md)


|

##### [org.dexcare.services.virtualvisit.models.SessionStatus](../org.dexcare.services.virtualvisit.models/-session-status/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.SignalMessage](../org.dexcare.services.virtualvisit.video.models.signaling/-signal-message/index.md)


| (extensions in package org.dexcare.dal.exts)

##### [io.reactivex.Single](../org.dexcare.dal.exts/io.reactivex.-single/index.md)


| (extensions in package org.dexcare.exts)

##### [io.reactivex.Single](../org.dexcare.exts/io.reactivex.-single/index.md)


|

##### [org.dexcare.services.retail.errors.SomeoneElseHasBookedError](../org.dexcare.services.retail.errors/-someone-else-has-booked-error/index.md)

This error indicates the time slot has already been booked by another user


|

##### [org.dexcare.services.models.SomeoneElseImageInsurance](../org.dexcare.services.models/-someone-else-image-insurance/index.md)

PaymentMethod for use when images of the front and back of the insurance card have been uploaded
using the RetailService.uploadInsuranceCard method, and the insurance is not owned by the
app user.


|

##### [org.dexcare.services.models.SomeoneElseManualInsurance](../org.dexcare.services.models/-someone-else-manual-insurance/index.md)

PaymentMethod for use when the insurance is owned by someone other than the app user.


|

##### [org.dexcare.services.retail.models.TimeSlot](../org.dexcare.services.retail.models/-time-slot/index.md)

Represents an available time for a Retail appointment


|

##### [org.dexcare.services.retail.errors.TimeSlotInPastError](../org.dexcare.services.retail.errors/-time-slot-in-past-error/index.md)

This error indicates the time slot is in the past and no longer available


|

##### [org.dexcare.services.virtualvisit.models.TokBoxInfo](../org.dexcare.services.virtualvisit.models/-tok-box-info/index.md)


|

##### [org.dexcare.services.virtualvisit.models.TokboxVisit](../org.dexcare.services.virtualvisit.models/-tokbox-visit/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.TypingState](../org.dexcare.services.virtualvisit.video.models.signaling/-typing-state/index.md)


|

##### [org.dexcare.services.retail.errors.UnavailableAppointmentError](../org.dexcare.services.retail.errors/-unavailable-appointment-error/index.md)

This error indicates the time slot selected is unavailable


|

##### [org.dexcare.services.patient.errors.UnexpectedMethodOrderError](../org.dexcare.services.patient.errors/-unexpected-method-order-error/index.md)

Something went wrong accessing the PatientCache
SDK consumer should ensure PatientService#getPatient is called at least once before any other patient service calls
SDK consumer should ensure PatientService#createPatient is called before scheduling a virtual visit


|

##### [org.dexcare.services.pcp.models.Vendor](../org.dexcare.services.pcp.models/-vendor/index.md)


|

##### [org.dexcare.services.virtualvisit.models.VideoConferenceSession](../org.dexcare.services.virtualvisit.models/-video-conference-session/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.VirtualCarePatient](../org.dexcare.services.virtualvisit.video.models/-virtual-care-patient/index.md)


|

##### [org.dexcare.services.virtualvisit.video.errors.VirtualError](../org.dexcare.services.virtualvisit.video.errors/-virtual-error/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.VirtualEvents](../org.dexcare.services.virtualvisit.video.models/-virtual-events/index.md)


|

##### [org.dexcare.services.pcp.models.VirtualMeeting](../org.dexcare.services.pcp.models/-virtual-meeting/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.VirtualSession](../org.dexcare.services.virtualvisit.video.models/-virtual-session/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.viewmodels.VirtualVisitCallViewModel](../org.dexcare.services.virtualvisit.video.fragment.viewmodels/-virtual-visit-call-view-model/index.md)


|

##### [org.dexcare.services.virtualvisit.errors.VirtualVisitCancelled](../org.dexcare.services.virtualvisit.errors/-virtual-visit-cancelled/index.md)


|

##### [org.dexcare.services.virtualvisit.errors.VirtualVisitFinished](../org.dexcare.services.virtualvisit.errors/-virtual-visit-finished/index.md)


|

##### [org.dexcare.services.virtualvisit.models.VirtualVisitIDs](../org.dexcare.services.virtualvisit.models/-virtual-visit-i-ds/index.md)


|

##### [org.dexcare.services.virtualvisit.models.VirtualVisitInformation](../org.dexcare.services.virtualvisit.models/-virtual-visit-information/index.md)


|

##### [org.dexcare.services.virtualvisit.errors.VirtualVisitNotFound](../org.dexcare.services.virtualvisit.errors/-virtual-visit-not-found/index.md)


|

##### [org.dexcare.services.virtualvisit.VirtualVisitService](../org.dexcare.services.virtualvisit/-virtual-visit-service/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.VirtualVisitViewModel](../org.dexcare.services.virtualvisit.video.fragment/-virtual-visit-view-model/index.md)


|

##### [org.dexcare.services.virtualvisit.models.VisitBody](../org.dexcare.services.virtualvisit.models/-visit-body/index.md)


|

##### [org.dexcare.services.virtualvisit.video.models.signaling.VisitStatus](../org.dexcare.services.virtualvisit.video.models.signaling/-visit-status/index.md)


|

##### [org.dexcare.services.pcp.models.VisitType](../org.dexcare.services.pcp.models/-visit-type/index.md)


|

##### [org.dexcare.services.retail.models.VisitType](../org.dexcare.services.retail.models/-visit-type/index.md)

An enum representing visit types supported by Epic.
In Retail, Illness is the only one in use.


|

##### [org.dexcare.services.internalservices.schedule.models.WaitingRoomSession](../org.dexcare.services.internalservices.schedule.models/-waiting-room-session/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.viewmodels.WaitingRoomViewModel](../org.dexcare.services.virtualvisit.video.fragment.viewmodels/-waiting-room-view-model/index.md)


|

##### [org.dexcare.services.virtualvisit.video.fragment.YouTubeVideoManager](../org.dexcare.services.virtualvisit.video.fragment/-you-tube-video-manager/index.md)


