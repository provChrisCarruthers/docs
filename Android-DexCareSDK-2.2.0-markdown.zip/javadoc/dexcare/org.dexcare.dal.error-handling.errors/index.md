[dexcare](../index.md) / [org.dexcare.dal.errorHandling.errors](./index.md)

## Package org.dexcare.dal.errorHandling.errors

### Exceptions

| Name | Summary |
|---|---|
| [DalNotInitError](-dal-not-init-error/index.md) | `class DalNotInitError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [NoBaseUrlSet](-no-base-url-set/index.md) | `class NoBaseUrlSet : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
