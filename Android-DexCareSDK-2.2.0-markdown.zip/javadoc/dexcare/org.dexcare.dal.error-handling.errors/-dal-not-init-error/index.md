[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.errors](../index.md) / [DalNotInitError](./index.md)

# DalNotInitError

`class DalNotInitError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `DalNotInitError()` |
