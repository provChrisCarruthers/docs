[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.errors](../index.md) / [DalNotInitError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`DalNotInitError()`