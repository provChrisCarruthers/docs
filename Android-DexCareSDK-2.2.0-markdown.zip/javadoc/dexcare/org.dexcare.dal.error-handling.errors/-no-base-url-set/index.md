[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.errors](../index.md) / [NoBaseUrlSet](./index.md)

# NoBaseUrlSet

`class NoBaseUrlSet : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `NoBaseUrlSet()` |
