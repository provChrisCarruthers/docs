[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.errors](../index.md) / [NoBaseUrlSet](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`NoBaseUrlSet()`