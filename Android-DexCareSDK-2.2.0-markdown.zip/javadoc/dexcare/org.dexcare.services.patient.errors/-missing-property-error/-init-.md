[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [MissingPropertyError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`MissingPropertyError(message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`