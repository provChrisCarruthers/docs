[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [MissingPropertyError](./index.md)

# MissingPropertyError

`class MissingPropertyError : `[`Exception`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-exception/index.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `MissingPropertyError(message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)` |
