[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [NoPatientLinkError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`NoPatientLinkError()`