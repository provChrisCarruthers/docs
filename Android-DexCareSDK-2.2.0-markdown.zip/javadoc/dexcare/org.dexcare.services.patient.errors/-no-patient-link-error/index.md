[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [NoPatientLinkError](./index.md)

# NoPatientLinkError

`class NoPatientLinkError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `NoPatientLinkError()` |
