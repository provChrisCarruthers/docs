[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [UnexpectedMethodOrderError](./index.md)

# UnexpectedMethodOrderError

`class UnexpectedMethodOrderError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

Something went wrong accessing the PatientCache
SDK consumer should ensure PatientService#getPatient is called at least once before any other patient service calls
SDK consumer should ensure PatientService#createPatient is called before scheduling a virtual visit

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Something went wrong accessing the PatientCache SDK consumer should ensure PatientService#getPatient is called at least once before any other patient service calls SDK consumer should ensure PatientService#createPatient is called before scheduling a virtual visit`UnexpectedMethodOrderError(message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null)` |
