[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [UnexpectedMethodOrderError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`UnexpectedMethodOrderError(message: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`? = null)`

Something went wrong accessing the PatientCache
SDK consumer should ensure PatientService#getPatient is called at least once before any other patient service calls
SDK consumer should ensure PatientService#createPatient is called before scheduling a virtual visit

