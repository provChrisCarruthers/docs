[dexcare](../../index.md) / [org.dexcare.services.patient.errors](../index.md) / [InvalidPatientDemographicsObjectError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`InvalidPatientDemographicsObjectError()`