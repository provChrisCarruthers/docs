[dexcare](../index.md) / [org.dexcare.services.patient.errors](./index.md)

## Package org.dexcare.services.patient.errors

### Exceptions

| Name | Summary |
|---|---|
| [InvalidPatientDemographicsObjectError](-invalid-patient-demographics-object-error/index.md) | `class InvalidPatientDemographicsObjectError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [MissingPropertyError](-missing-property-error/index.md) | `class MissingPropertyError : `[`Exception`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-exception/index.html) |
| [NoPatientLinkError](-no-patient-link-error/index.md) | `class NoPatientLinkError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
| [UnexpectedMethodOrderError](-unexpected-method-order-error/index.md) | Something went wrong accessing the PatientCache SDK consumer should ensure PatientService#getPatient is called at least once before any other patient service calls SDK consumer should ensure PatientService#createPatient is called before scheduling a virtual visit`class UnexpectedMethodOrderError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
