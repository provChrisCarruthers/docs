[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [error](./error.md)

# error

`protected var error: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`?`