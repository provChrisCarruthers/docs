[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [dispose](./dispose.md)

# dispose

`fun dispose(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)

This will dispose any api calls being made from this observer

