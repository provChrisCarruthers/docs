[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [subscribe](./subscribe.md)

# subscribe

`fun subscribe(onSuccess: (T) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`, onError: (`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)` = {}, thread: Thread = Thread.Main): `[`DataObserver`](index.md)`<T>`

This will allow users to subscribe for data

### Parameters

`onSuccess` - this will be called only when data has successfully been retrieve

`onError` - this will be called only when a throwable has been thrown

`thread` - allows you to set which thread data should be return to. Default is main.