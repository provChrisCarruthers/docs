[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [data](./data.md)

# data

`protected var data: T?`