[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [isDisposed](./is-disposed.md)

# isDisposed

`fun isDisposed(): `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html)

**Return**
Whether the observer has been disposed.  Returns true if the observer hasn't been started.

