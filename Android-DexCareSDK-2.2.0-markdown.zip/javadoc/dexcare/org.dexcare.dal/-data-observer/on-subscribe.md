[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [onSubscribe](./on-subscribe.md)

# onSubscribe

`protected abstract fun onSubscribe(onSuccess: (T) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`, onError: (`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)` = {}, thread: Thread = Thread.Main): `[`DataObserver`](index.md)`<T>`