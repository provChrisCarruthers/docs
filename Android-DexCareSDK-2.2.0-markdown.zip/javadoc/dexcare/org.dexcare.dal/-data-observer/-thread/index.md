[dexcare](../../../index.md) / [org.dexcare.dal](../../index.md) / [DataObserver](../index.md) / [Thread](./index.md)

# Thread

`enum class Thread`

### Enum Values

| Name | Summary |
|---|---|
| [Main](-main.md) |  |
| [IO](-i-o.md) |  |
