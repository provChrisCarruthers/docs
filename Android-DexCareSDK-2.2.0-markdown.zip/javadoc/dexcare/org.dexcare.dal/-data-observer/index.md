[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](./index.md)

# DataObserver

`abstract class DataObserver<T> : LifecycleObserver`

Public facing interface for users to grab data

### Types

| Name | Summary |
|---|---|
| [Thread](-thread/index.md) | `enum class Thread` |

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | Public facing interface for users to grab data`DataObserver()` |

### Properties

| Name | Summary |
|---|---|
| [data](data.md) | `var data: T?` |
| [disposable](disposable.md) | `var disposable: Disposable?` |
| [error](error.md) | `var error: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`?` |
| [onDisposed](on-disposed.md) | `var onDisposed: (() -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`)?` |

### Functions

| Name | Summary |
|---|---|
| [dispose](dispose.md) | This will dispose any api calls being made from this observer`fun dispose(): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html) |
| [isDisposed](is-disposed.md) | `fun isDisposed(): `[`Boolean`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-boolean/index.html) |
| [onSubscribe](on-subscribe.md) | `abstract fun onSubscribe(onSuccess: (T) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`, onError: (`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)` = {}, thread: Thread = Thread.Main): `[`DataObserver`](./index.md)`<T>` |
| [subscribe](subscribe.md) | This will allow users to subscribe for data`fun subscribe(onSuccess: (T) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`, onError: (`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`) -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)` = {}, thread: Thread = Thread.Main): `[`DataObserver`](./index.md)`<T>` |

### Extension Functions

| Name | Summary |
|---|---|
| [convertToRxJava](../../org.dexcare.exts/convert-to-rx-java.md) | `fun <T> `[`DataObserver`](./index.md)`<T>.convertToRxJava(): Single<T>` |
| [getNow](../../org.dexcare.exts/get-now.md) | `fun <T> `[`DataObserver`](./index.md)`<T>.getNow(): `[`Pair`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-pair/index.html)`<T?, `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`?>` |
