[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [onDisposed](./on-disposed.md)

# onDisposed

`var onDisposed: (() -> `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)`)?`