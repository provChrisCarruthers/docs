[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`DataObserver()`

Public facing interface for users to grab data

