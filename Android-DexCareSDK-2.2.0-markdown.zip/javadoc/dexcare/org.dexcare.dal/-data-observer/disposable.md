[dexcare](../../index.md) / [org.dexcare.dal](../index.md) / [DataObserver](index.md) / [disposable](./disposable.md)

# disposable

`protected var disposable: Disposable?`