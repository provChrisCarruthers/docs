[dexcare](../index.md) / [org.dexcare.dal](./index.md)

## Package org.dexcare.dal

### Types

| Name | Summary |
|---|---|
| [DataObserver](-data-observer/index.md) | Public facing interface for users to grab data`abstract class DataObserver<T> : LifecycleObserver` |
