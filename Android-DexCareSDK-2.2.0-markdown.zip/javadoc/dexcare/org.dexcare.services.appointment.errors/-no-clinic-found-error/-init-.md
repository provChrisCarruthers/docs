[dexcare](../../index.md) / [org.dexcare.services.appointment.errors](../index.md) / [NoClinicFoundError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`NoClinicFoundError()`