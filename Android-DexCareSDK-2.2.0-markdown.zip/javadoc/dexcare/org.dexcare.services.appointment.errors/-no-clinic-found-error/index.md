[dexcare](../../index.md) / [org.dexcare.services.appointment.errors](../index.md) / [NoClinicFoundError](./index.md)

# NoClinicFoundError

`class NoClinicFoundError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `NoClinicFoundError()` |
