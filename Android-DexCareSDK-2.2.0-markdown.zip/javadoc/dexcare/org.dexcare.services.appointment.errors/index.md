[dexcare](../index.md) / [org.dexcare.services.appointment.errors](./index.md)

## Package org.dexcare.services.appointment.errors

### Exceptions

| Name | Summary |
|---|---|
| [NoClinicFoundError](-no-clinic-found-error/index.md) | `class NoClinicFoundError : `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html) |
