[dexcare](../../index.md) / [org.dexcare.services.virtualvisit.errors](../index.md) / [NeedPermissionError](index.md) / [permissions](./permissions.md)

# permissions

`vararg val permissions: `[`Array`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-array/index.html)`<out `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`>`