[dexcare](../../index.md) / [org.dexcare.services.virtualvisit.errors](../index.md) / [NeedPermissionError](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`NeedPermissionError(vararg permissions: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)`)`