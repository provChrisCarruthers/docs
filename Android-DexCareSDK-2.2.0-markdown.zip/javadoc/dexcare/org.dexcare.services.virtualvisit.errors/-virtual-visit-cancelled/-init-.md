[dexcare](../../index.md) / [org.dexcare.services.virtualvisit.errors](../index.md) / [VirtualVisitCancelled](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`VirtualVisitCancelled()`