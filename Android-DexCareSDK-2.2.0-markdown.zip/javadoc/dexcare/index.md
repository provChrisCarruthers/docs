[dexcare](./index.md)

### Packages

| Name | Summary |
|---|---|
| [org.dexcare](org.dexcare/index.md) |  |
| [org.dexcare.dal](org.dexcare.dal/index.md) |  |
| [org.dexcare.dal.errorHandling.errors](org.dexcare.dal.error-handling.errors/index.md) |  |
| [org.dexcare.dal.errorHandling.retries](org.dexcare.dal.error-handling.retries/index.md) |  |
| [org.dexcare.dal.exts](org.dexcare.dal.exts/index.md) |  |
| [org.dexcare.dal.network](org.dexcare.dal.network/index.md) |  |
| [org.dexcare.exts](org.dexcare.exts/index.md) |  |
| [org.dexcare.logs](org.dexcare.logs/index.md) |  |
| [org.dexcare.services](org.dexcare.services/index.md) |  |
| [org.dexcare.services.appointment](org.dexcare.services.appointment/index.md) |  |
| [org.dexcare.services.appointment.errors](org.dexcare.services.appointment.errors/index.md) |  |
| [org.dexcare.services.appointment.models](org.dexcare.services.appointment.models/index.md) |  |
| [org.dexcare.services.auth.models](org.dexcare.services.auth.models/index.md) |  |
| [org.dexcare.services.internalservices.schedule.models](org.dexcare.services.internalservices.schedule.models/index.md) |  |
| [org.dexcare.services.models](org.dexcare.services.models/index.md) |  |
| [org.dexcare.services.patient](org.dexcare.services.patient/index.md) |  |
| [org.dexcare.services.patient.errors](org.dexcare.services.patient.errors/index.md) |  |
| [org.dexcare.services.patient.models](org.dexcare.services.patient.models/index.md) |  |
| [org.dexcare.services.pcp.models](org.dexcare.services.pcp.models/index.md) |  |
| [org.dexcare.services.retail](org.dexcare.services.retail/index.md) |  |
| [org.dexcare.services.retail.errors](org.dexcare.services.retail.errors/index.md) |  |
| [org.dexcare.services.retail.models](org.dexcare.services.retail.models/index.md) |  |
| [org.dexcare.services.virtualvisit](org.dexcare.services.virtualvisit/index.md) |  |
| [org.dexcare.services.virtualvisit.errors](org.dexcare.services.virtualvisit.errors/index.md) |  |
| [org.dexcare.services.virtualvisit.models](org.dexcare.services.virtualvisit.models/index.md) |  |
| [org.dexcare.services.virtualvisit.video.errors](org.dexcare.services.virtualvisit.video.errors/index.md) |  |
| [org.dexcare.services.virtualvisit.video.fragment](org.dexcare.services.virtualvisit.video.fragment/index.md) |  |
| [org.dexcare.services.virtualvisit.video.fragment.uiviews](org.dexcare.services.virtualvisit.video.fragment.uiviews/index.md) |  |
| [org.dexcare.services.virtualvisit.video.fragment.viewmodels](org.dexcare.services.virtualvisit.video.fragment.viewmodels/index.md) |  |
| [org.dexcare.services.virtualvisit.video.models](org.dexcare.services.virtualvisit.video.models/index.md) |  |
| [org.dexcare.services.virtualvisit.video.models.signaling](org.dexcare.services.virtualvisit.video.models.signaling/index.md) |  |

### Index

[All Types](alltypes/index.md)