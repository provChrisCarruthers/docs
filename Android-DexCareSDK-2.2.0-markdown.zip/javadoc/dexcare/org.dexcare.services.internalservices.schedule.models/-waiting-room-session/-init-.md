[dexcare](../../index.md) / [org.dexcare.services.internalservices.schedule.models](../index.md) / [WaitingRoomSession](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`WaitingRoomSession(sessionId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "", patientToken: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "")`