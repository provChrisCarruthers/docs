[dexcare](../../index.md) / [org.dexcare.services.internalservices.schedule.models](../index.md) / [WaitingRoomSession](index.md) / [sessionId](./session-id.md)

# sessionId

`var sessionId: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)