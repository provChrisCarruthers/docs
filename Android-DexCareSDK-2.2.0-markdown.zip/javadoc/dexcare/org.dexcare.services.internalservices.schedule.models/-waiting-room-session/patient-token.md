[dexcare](../../index.md) / [org.dexcare.services.internalservices.schedule.models](../index.md) / [WaitingRoomSession](index.md) / [patientToken](./patient-token.md)

# patientToken

`var patientToken: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)