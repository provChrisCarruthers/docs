[dexcare](../index.md) / [org.dexcare.services.internalservices.schedule.models](./index.md)

## Package org.dexcare.services.internalservices.schedule.models

### Types

| Name | Summary |
|---|---|
| [WaitingRoomSession](-waiting-room-session/index.md) | `data class WaitingRoomSession : `[`Parcelable`](https://developer.android.com/reference/android/os/Parcelable.html) |
