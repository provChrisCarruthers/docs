[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [GeneralRetry](index.md) / [handleThrowable](./handle-throwable.md)

# handleThrowable

`fun handleThrowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>`