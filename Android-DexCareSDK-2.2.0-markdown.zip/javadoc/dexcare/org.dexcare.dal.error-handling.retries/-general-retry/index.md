[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [GeneralRetry](./index.md)

# GeneralRetry

`class GeneralRetry : `[`BaseRetry`](../-base-retry/index.md)

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `GeneralRetry(maxRetries: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L)` |

### Functions

| Name | Summary |
|---|---|
| [handleThrowable](handle-throwable.md) | `fun handleThrowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>` |
