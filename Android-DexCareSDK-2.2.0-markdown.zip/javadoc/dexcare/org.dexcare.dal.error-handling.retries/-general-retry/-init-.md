[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [GeneralRetry](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`GeneralRetry(maxRetries: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 2, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L)`