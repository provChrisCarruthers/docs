[dexcare](../index.md) / [org.dexcare.dal.errorHandling.retries](./index.md)

## Package org.dexcare.dal.errorHandling.retries

### Types

| Name | Summary |
|---|---|
| [BaseRetry](-base-retry/index.md) | This provides an interface to implement a retrywhen for flowables`abstract class BaseRetry : Function<Flowable<`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`>, Flowable<*>>` |
| [GeneralRetry](-general-retry/index.md) | `class GeneralRetry : `[`BaseRetry`](-base-retry/index.md) |
| [HttpRetry](-http-retry/index.md) | This is an implementation to catch network exceptions for retrywhen`abstract class HttpRetry : `[`BaseRetry`](-base-retry/index.md) |
