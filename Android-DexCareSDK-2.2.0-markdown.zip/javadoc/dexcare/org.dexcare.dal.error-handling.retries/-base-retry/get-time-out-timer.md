[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [BaseRetry](index.md) / [getTimeOutTimer](./get-time-out-timer.md)

# getTimeOutTimer

`protected fun getTimeOutTimer(retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)`): Flowable<*>`