[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [BaseRetry](index.md) / [apply](./apply.md)

# apply

`open fun apply(t: Flowable<`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`>): Flowable<*>`