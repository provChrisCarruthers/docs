[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [BaseRetry](./index.md)

# BaseRetry

`abstract class BaseRetry : Function<Flowable<`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`>, Flowable<*>>`

This provides an interface to implement a retrywhen for flowables

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This provides an interface to implement a retrywhen for flowables`BaseRetry()` |

### Functions

| Name | Summary |
|---|---|
| [apply](apply.md) | `open fun apply(t: Flowable<`[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`>): Flowable<*>` |
| [getTimeOutTimer](get-time-out-timer.md) | `fun getTimeOutTimer(retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)`): Flowable<*>` |
| [handleThrowable](handle-throwable.md) | `abstract fun handleThrowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>` |

### Inheritors

| Name | Summary |
|---|---|
| [GeneralRetry](../-general-retry/index.md) | `class GeneralRetry : `[`BaseRetry`](./index.md) |
| [HttpRetry](../-http-retry/index.md) | This is an implementation to catch network exceptions for retrywhen`abstract class HttpRetry : `[`BaseRetry`](./index.md) |
