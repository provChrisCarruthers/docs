[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [BaseRetry](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`BaseRetry()`

This provides an interface to implement a retrywhen for flowables

