[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](index.md) / [retryDelayMS](./retry-delay-m-s.md)

# retryDelayMS

`val retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)