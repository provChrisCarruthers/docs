[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](./index.md)

# HttpRetry

`abstract class HttpRetry : `[`BaseRetry`](../-base-retry/index.md)

This is an implementation to catch network exceptions for retrywhen

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | This is an implementation to catch network exceptions for retrywhen`HttpRetry(maxRetries: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 3, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L)` |

### Properties

| Name | Summary |
|---|---|
| [maxRetries](max-retries.md) | `val maxRetries: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [retryCount](retry-count.md) | `var retryCount: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html) |
| [retryDelayMS](retry-delay-m-s.md) | `val retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html) |

### Functions

| Name | Summary |
|---|---|
| [getRetryFlowable](get-retry-flowable.md) | `fun getRetryFlowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>` |
| [handleHttpError](handle-http-error.md) | `abstract fun handleHttpError(httpException: HttpException): Flowable<*>` |
| [handleThrowable](handle-throwable.md) | `open fun handleThrowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>` |
