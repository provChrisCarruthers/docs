[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](index.md) / [getRetryFlowable](./get-retry-flowable.md)

# getRetryFlowable

`protected fun getRetryFlowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>`