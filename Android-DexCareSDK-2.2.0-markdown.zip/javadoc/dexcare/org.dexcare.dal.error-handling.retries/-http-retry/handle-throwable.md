[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](index.md) / [handleThrowable](./handle-throwable.md)

# handleThrowable

`open fun handleThrowable(throwable: `[`Throwable`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-throwable/index.html)`): Flowable<*>`