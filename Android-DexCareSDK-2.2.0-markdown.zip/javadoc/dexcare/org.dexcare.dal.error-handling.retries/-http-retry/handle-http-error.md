[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](index.md) / [handleHttpError](./handle-http-error.md)

# handleHttpError

`abstract fun handleHttpError(httpException: HttpException): Flowable<*>`