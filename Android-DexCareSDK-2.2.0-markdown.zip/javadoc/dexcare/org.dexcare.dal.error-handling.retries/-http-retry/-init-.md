[dexcare](../../index.md) / [org.dexcare.dal.errorHandling.retries](../index.md) / [HttpRetry](index.md) / [&lt;init&gt;](./-init-.md)

# &lt;init&gt;

`HttpRetry(maxRetries: `[`Int`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-int/index.html)` = 3, retryDelayMS: `[`Long`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-long/index.html)` = 1000L)`

This is an implementation to catch network exceptions for retrywhen

