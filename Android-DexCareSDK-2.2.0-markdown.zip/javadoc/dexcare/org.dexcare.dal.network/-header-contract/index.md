[dexcare](../../index.md) / [org.dexcare.dal.network](../index.md) / [HeaderContract](./index.md)

# HeaderContract

`interface HeaderContract`

### Functions

| Name | Summary |
|---|---|
| [setupHeaders](setup-headers.md) | `abstract fun setupHeaders(builder: Builder): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html) |
