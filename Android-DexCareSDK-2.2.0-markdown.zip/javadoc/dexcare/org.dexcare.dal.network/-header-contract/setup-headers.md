[dexcare](../../index.md) / [org.dexcare.dal.network](../index.md) / [HeaderContract](index.md) / [setupHeaders](./setup-headers.md)

# setupHeaders

`abstract fun setupHeaders(builder: Builder): `[`Unit`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-unit/index.html)