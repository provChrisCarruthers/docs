[dexcare](../index.md) / [org.dexcare.dal.network](./index.md)

## Package org.dexcare.dal.network

### Types

| Name | Summary |
|---|---|
| [HeaderContract](-header-contract/index.md) | `interface HeaderContract` |
