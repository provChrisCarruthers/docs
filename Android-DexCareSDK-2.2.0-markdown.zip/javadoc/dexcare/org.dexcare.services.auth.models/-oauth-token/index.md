[dexcare](../../index.md) / [org.dexcare.services.auth.models](../index.md) / [OauthToken](./index.md)

# OauthToken

`data class OauthToken`

### Constructors

| Name | Summary |
|---|---|
| [&lt;init&gt;](-init-.md) | `OauthToken(accessToken: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)` = "")` |

### Properties

| Name | Summary |
|---|---|
| [accessToken](access-token.md) | `val accessToken: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html) |
