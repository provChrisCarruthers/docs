[dexcare](../../index.md) / [org.dexcare.services.auth.models](../index.md) / [OauthToken](index.md) / [accessToken](./access-token.md)

# accessToken

`val accessToken: `[`String`](https://kotlinlang.org/api/latest/jvm/stdlib/kotlin/-string/index.html)