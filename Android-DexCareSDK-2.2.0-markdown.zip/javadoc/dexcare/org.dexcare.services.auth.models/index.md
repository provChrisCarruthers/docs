[dexcare](../index.md) / [org.dexcare.services.auth.models](./index.md)

## Package org.dexcare.services.auth.models

### Types

| Name | Summary |
|---|---|
| [OauthToken](-oauth-token/index.md) | `data class OauthToken` |
